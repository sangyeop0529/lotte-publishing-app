// *************************************************************************
// *************************************************************************
// * 2025.03.31 작업
// * 작업자 : 조윤상
// * version : v2.0 (2026.11.12 리팩토링 · 메시지 규격 v2)
// * outer.js와 자식 js는 반드시 같은 버전끼리 함께 배포
// *************************************************************************
// *************************************************************************

// * 부모 페이지 전역과 이름이 겹치지 않도록 전체를 즉시 실행 함수로 감쌈
// * (운영 페이지의 getIframeHeight, openNhldyCartGuide 등과 충돌 방지 · 밖으로 노출하는 값 없음)
(() => {
  // TODO ********************************************************************
  // ! 전역 변수
  // TODO ********************************************************************

  // * 실행 중 추가되는 값 : deviceState, basePath, imgPath, isSwiper,
  // * tabAreaHeight, tabAreaPosition, tabBtnAreaHeight, tabBtnAreaPosition
  const initOuterObj = {
    basicTopPosition: 1,
    modalSwipers: [], // * 모달 안 Swiper (닫을 때 destroy)
  };

  const util = document.querySelector(".util");
  const utilHeader = util?.getBoundingClientRect().height ?? 0;

  // ! getPcHeaderH - PC 상단 고정 헤더 높이 (util + header) [S]
  const getPcHeaderH = () => {
    const header = document.querySelector(".header__container");
    return utilHeader + (header ? header.getBoundingClientRect().height : 0);
  };
  // getPcHeaderH - PC 상단 고정 헤더 높이 (util + header) [E]

  // ! isNearScroll - 스크롤 위치가 target ±1px(정수)인지 [S]
  // * 중복 클릭 판정용 (기존 ==, -1, +1 세 번 비교와 동일)
  const isNearScroll = (scrollTop, target) =>
    scrollTop === target ||
    scrollTop === target - 1 ||
    scrollTop === target + 1;
  // isNearScroll - 스크롤 위치가 target ±1px(정수)인지 [E]

  // TODO ********************************************************************
  // ! postMessage 동작 - 보내기
  // TODO ********************************************************************

  // ! loadScriptOnce - 스크립트 1회 로드 [S]
  // * 같은 src는 한 번만 로드하고, 로드 완료 시점을 Promise로 알려준다
  const scriptLoadMap = {};
  const loadScriptOnce = (src) => {
    if (!scriptLoadMap[src]) {
      scriptLoadMap[src] = new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.type = "text/javascript";
        script.src = src;
        script.onload = resolve;
        script.onerror = () => {
          delete scriptLoadMap[src];
          reject(new Error(`script load error: ${src}`));
        };
        document.head.appendChild(script);
      });
    }
    return scriptLoadMap[src];
  };
  // loadScriptOnce - 스크립트 1회 로드 [E]

  // ! loadSwiper - Swiper CDN 1회 로드 [S]
  // * css는 한 번만 추가하고, js 로드가 끝나면 resolve (탭 복제 · 모달 공용)
  const SWIPER_CDN = "https://cdn.jsdelivr.net/npm/swiper@11.2.10";
  const loadSwiper = () => {
    if (!document.querySelector("link[data-if-swiper]")) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = `${SWIPER_CDN}/swiper-bundle.min.css`;
      link.dataset.ifSwiper = "";
      document.head.appendChild(link);
    }
    return loadScriptOnce(`${SWIPER_CDN}/swiper-bundle.min.js`);
  };
  // loadSwiper - Swiper CDN 1회 로드 [E]

  // ! getIframe - 콘텐츠 iframe 찾기 [S]
  // the_iframe : 쇼핑뉴스 iframe / detailHTML : 이벤트 iframe
  // 둘 다 있으면 쇼핑뉴스(the_iframe) 우선, 없으면 null
  const getIframe = () =>
    document.getElementById("the_iframe") ||
    document.getElementById("detailHTML");
  // getIframe - 콘텐츠 iframe 찾기 [E]

  // ! sendToIframe - iframe으로 메세지 보내기 [S]
  // * 모든 부모 → 자식 메세지는 이 함수로만 보낸다
  // * targetOrigin은 iframe의 출처로 고정 (iframe이 다른 곳으로 이동하면 전달되지 않음)
  const getIframeOrigin = (iframe) => {
    try {
      const origin = new URL(iframe.src, window.location.href).origin;
      return origin && origin !== "null" ? origin : "*";
    } catch (e) {
      return "*";
    }
  };

  const sendToIframe = (fnNm, param) => {
    const iframe = getIframe();
    if (!iframe || !iframe.contentWindow) return;

    const data = param === undefined ? { fnNm } : { fnNm, param };
    iframe.contentWindow.postMessage(data, getIframeOrigin(iframe));
  };
  // sendToIframe - iframe으로 메세지 보내기 [E]

  // ! getDeviceSet - 디바이스 설정값 메세지 보내기 [S]
  const getDeviceSet = () => {
    if (!document.body.classList.contains("kiosk")) {
      if (!document.querySelector(".snb")) {
        // * PC
        initOuterObj.deviceState = "pc";
      } else {
        const browserInfo = navigator.userAgent;
        if (
          browserInfo.indexOf("LD_Android") > -1 ||
          browserInfo.indexOf("LD_iOS") > -1
        ) {
          // * APP
          initOuterObj.deviceState = "app";
        } else {
          // * MO
          initOuterObj.deviceState = "mo";
        }
      }
    } else {
      // * KIOSK
      initOuterObj.deviceState = "kiosk";
    }

    sendToIframe("setDevice", { deviceState: initOuterObj.deviceState });
  };
  // getDeviceSet - 디바이스 설정값 메세지 보내기 [E]

  // ! iframe 높이값 [S]
  // * requestIframeHeight : 자식에게 "현재 높이를 보내달라" 요청
  const requestIframeHeight = () => {
    sendToIframe("requestIframeHeight");
  };

  // * setIframeHeight : 자식이 보낸 높이를 적용하고, 다시 한 번 확인 요청
  // * (자식은 높이가 그대로면 응답하지 않으므로 무한 반복되지 않음)
  const setIframeHeight = (iframeHeight) => {
    const iframe = getIframe();
    if (!iframe || !iframeHeight) return;

    iframe.style.height = `${iframeHeight}px`;
    requestIframeHeight();
  };
  // iframe 높이값 [E]

  // ! getTabValues - 탭 상세,탭 버튼 영역 높이값 & 탭 상세,탭 버튼 영역 위치값 설정 메세지 보내기 [S]
  const getTabValues = () => {
    sendToIframe("requestTabValues");
  };
  // getTabValues - 탭 상세,탭 버튼 영역 높이값 & 탭 상세,탭 버튼 영역 위치값 설정 메세지 보내기 [E]

  // ! getTabCloneData - 탭 복사 데이터 설정 메세지 보내기 [S]
  const getTabCloneData = () => {
    sendToIframe("requestTabClone");
  };
  // getTabCloneData - 탭 복사 데이터 설정 메세지 보내기 [E]

  // ! ifSlideTransform - 탭 연동 설정 보내기 [S]
  const ifSlideTransform = (transform) => {
    sendToIframe("tabSlideMove", { transform });
  };
  // ifSlideTransform - 탭 연동 설정 보내기 [E]

  // ! getModalCreateData - 모달 만들기 데이터 설정 메세지 보내기 [S]
  const getModalCreateData = () => {
    sendToIframe("modalWrapCreate");
  };
  // getModalCreateData - 모달 만들기 데이터 설정 메세지 보내기 [E]

  // ! ifModalContentEdit - 모달 수정 메세지 보내기 [S]
  const ifModalContentEdit = (content) => {
    const modalLink = content.includes("if-link-btn");

    sendToIframe("modalContentEdit", { modalLink });
  };
  // ifModalContentEdit - 모달 수정 메세지 보내기 [E]

  // ! getIframeVisibilityChange - 컨텐츠 변경 시, 메세지 보내기 [S]
  const getIframeVisibilityChange = () => {
    sendToIframe("pageVisibilityChange", { audioState: true });
  };
  // getIframeVisibilityChange - 컨텐츠 변경 시, 메세지 보내기 [E]

  // ! requestFixedBg - 고정 백그라운드 설정 요청 메세지 보내기 [S]
  // * 자식에 fixedBg.js가 있으면 setFixedBg로 응답 → getFixedBg에서 배경 적용
  // * fixedBg.js가 없는 콘텐츠는 응답이 없으므로 배경을 적용하지 않음
  const requestFixedBg = () => {
    sendToIframe("requestFixedBg");
  };
  // requestFixedBg - 고정 백그라운드 설정 요청 메세지 보내기 [E]

  // TODO ********************************************************************
  // ! postMessage 동작 - 받기
  // TODO ********************************************************************

  // ! isAllowedMessage - 받은 메세지 검증 [S]
  // * 1) 우리 콘텐츠 iframe이 보낸 메세지인지 (message.source)
  // * 2) 허용된 출처인지 (message.origin)
  const ALLOWED_ORIGINS = [
    "https://www.lotteshopping.com", // 국문 PC
    "https://m.lotteshopping.com", // 국문 MO/APP
    "https://minfo.lotteshopping.com", // 콘텐츠/이미지
    "https://global.lotteshopping.com", // 다국어 PC
    "https://m.global.lotteshopping.com", // 다국어 MO/APP
    "http://124.243.59.42:9094", // 개발기
  ];
  const LOCAL_ORIGIN = /^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/; // 로컬

  const isAllowedMessage = (message) => {
    const iframe = getIframe();
    if (!iframe || message.source !== iframe.contentWindow) return false;

    const origin = message.origin;
    return (
      origin === window.location.origin ||
      ALLOWED_ORIGINS.includes(origin) ||
      LOCAL_ORIGIN.test(origin)
    );
  };
  // isAllowedMessage - 받은 메세지 검증 [E]

  // ! iframe message receive - iframe에서 메세지 받기 [S]
  // * fnNm별 처리 함수 목록 (메세지 추가 시 여기에 함수만 추가)
  const messageHandlers = {
    // * iframe/outer 싱크
    iframeReady() {
      iframeReady = true;
      sendToIframe("outerReady");
    },

    // * 이미지 경로 설정
    setImgPath(param) {
      if (!param || !param.basePath || !param.imgPath) return;
      initOuterObj.basePath = param.basePath;
      initOuterObj.imgPath = param.imgPath;
    },

    // * iframe 높이값 설정
    iframeHeight(param) {
      if (!param || !param.height) return;
      setIframeHeight(param.height);
    },

    // * 탭 상세,탭 버튼 영역 높이값 & 탭 상세,탭 버튼 영역 위치값 설정
    tabValues(param) {
      if (!param) return;

      if (
        param.tabAreaHeight &&
        param.tabAreaPosition &&
        param.tabBtnAreaHeight &&
        typeof param.tabBtnAreaPosition == "number"
      ) {
        initOuterObj.tabAreaHeight = param.tabAreaHeight;
        initOuterObj.tabAreaPosition = param.tabAreaPosition;
        initOuterObj.tabBtnAreaHeight = param.tabBtnAreaHeight;
        initOuterObj.tabBtnAreaPosition = param.tabBtnAreaPosition;
      }
    },

    // * 탭 복사 설정
    tabClone(param) {
      if (!param || !param.count || !param.imgExtension) return;
      if (param.isSwiper) {
        initOuterObj.isSwiper = param.isSwiper;
      }
      getIframeTabClone(param.count, param.imgExtension);
    },

    // * 탭 클릭 설정
    tabClickAction(param) {
      if (!param || param.tabIdx == undefined) return;
      getTabClickAction(param.tabIdx);
    },

    // * 탭 연동 설정
    tabSlideMove(param) {
      if (!param || param.transform == undefined) return;
      const swiperWrapper = document.querySelector(
        ".tab-btn-area.swiper-tab .swiper-wrapper",
      );
      if (!swiperWrapper) return;

      swiperWrapper.style.transform = `translate3d(${param.transform}px, 0px, 0px)`;
    },

    // * 타겟 위치 스크롤 이동
    targetMoveScroll(param) {
      if (!param || !param.targetPosition) return;
      targetMoveScrollAction(param.targetPosition);
    },

    // * 모달 만들기
    modalWrapCreate(param) {
      if (!param || !param.modalImgPath) return;
      getModalWrapCreate(
        param.modalImgPath,
        param.modalState,
        param.headerState,
      );
    },

    // * 모달 열기 설정
    modalOpen(param) {
      if (!param || !param.modalContent) return;
      modalOpenAction(param.modalContent);
    },

    // * 모달 링크 설정
    setModalLink(param) {
      if (
        !param ||
        !param.modalLinkObj ||
        !param.linkJsPath ||
        !param.ga4EventJsPath ||
        !param.contentCode ||
        !param.contentName
      ) {
        return;
      }

      const modalLinkAll = document.querySelectorAll(".if-link-btn");

      const APP_EVENT = (label, addInfo) => {
        // <!-- ! lable : 버튼명, addInfo : 이벤트 부가정보 -->
        ga4Event.event(
          "click_event",
          "APP_쇼핑뉴스상세",
          "하단버튼",
          label,
          addInfo,
        );
      };

      // * link.js, ga4Event.js 로드가 끝난 뒤 링크 연결
      Promise.all([
        loadScriptOnce(param.linkJsPath),
        loadScriptOnce(param.ga4EventJsPath),
      ])
        .then(() => {
          modalLinkAll.forEach((element, idx) => {
            element.onclick = () => {
              APP_EVENT(
                param.modalLinkObj[idx].value,
                `${param.contentName}_${param.contentCode}`,
              );
            };
            LinkSetting(
              element,
              param.modalLinkObj[idx].type,
              "yes",
              param.modalLinkObj[idx].url,
            );
          });
        })
        .catch((error) => {
          console.error("[outer] 모달 링크 스크립트 로드 실패", error);
        });
    },

    // * 고정 백그라운드 설정
    setFixedBg() {
      getFixedBg();
    },
  };

  window.addEventListener("message", (message) => {
    // if (!isAllowedMessage(message)) return;

    const data = message.data;
    if (!data || !data.fnNm) return;

    const handler = messageHandlers[data.fnNm];
    if (handler) handler(data.param);
  });
  // iframe message receive - iframe에서 메세지 받기 [E]

  // TODO ********************************************************************
  // ! window 내부 동작
  // TODO ********************************************************************

  // ! getBasicTop setting - 기본 탑 위치값 설정 [S]
  // * 리사이즈 등으로 연속 호출되면 마지막 호출 300ms 뒤에 한 번만 계산
  // * (기존 old/basic 값 비교는 값이 한 번 같아지면 이후 재계산이 영구히 멈추는 문제가 있어 제거)
  let basicTopTimer = null;
  const getBasicTop = () => {
    const iframe = getIframe();

    if (iframe) {
      clearTimeout(basicTopTimer);
      basicTopTimer = setTimeout(() => {
        const headEl = document.querySelector(".__head");
        const detailEl = document.querySelector(".__detail__");

        if (!detailEl) return;

        const headH = headEl?.getBoundingClientRect().height ?? 0;
        const headDetail =
          headH + detailEl.getBoundingClientRect().top + window.pageYOffset;

        if (initOuterObj.deviceState == "pc") {
          // PC
          initOuterObj.basicTopPosition = headDetail + 2;
        } else if (
          initOuterObj.deviceState == "mo" ||
          initOuterObj.deviceState == "app"
        ) {
          // APP, MO
          initOuterObj.basicTopPosition =
            headDetail -
            document.querySelector(".snb").getBoundingClientRect().height +
            1;
        } else if (initOuterObj.deviceState == "kiosk") {
          // KIOSK
          initOuterObj.basicTopPosition =
            headDetail -
            document.querySelector("#kiosk-snb").getBoundingClientRect().height;
        }
      }, 300);
    }
  };
  // getBasicTop setting - 기본 탑 위치값 설정 [E]

  // ! getIframeTabClone setting - 탭 복사 [S]
  const getIframeTabClone = (count, imgExtension) => {
    // * 이미 복제 탭이 있으면 다시 만들지 않음 (중복 생성 · 중복 클릭 이벤트 방지)
    if (document.querySelector(".if-tab-clone-wrap")) return;

    const container = document.querySelector("#container");
    const ifTabCloneWrap = document.createElement("div");

    ifTabCloneWrap.style.cssText = `
      width: 100%;
      position: fixed;
      transition: top 0.5s;
      visibility: hidden;
    `;

    ifTabCloneWrap.classList.add("if-tab-clone-wrap");
    container.prepend(ifTabCloneWrap);

    // * 복제 탭 위치
    if (initOuterObj.deviceState == "pc") {
      ifTabCloneWrap.style.width = "758px";
      ifTabCloneWrap.style.top = document.body.classList.contains("down")
        ? "0px"
        : `${getPcHeaderH()}px`;
    } else if (
      initOuterObj.deviceState == "mo" ||
      initOuterObj.deviceState == "app"
    ) {
      ifTabCloneWrap.style.top = `${
        document.querySelector(".snb").getBoundingClientRect().height
      }px`;
    }

    // * 탭 버튼 : 첫 번째 탭 on, 스와이퍼면 swiper-slide 추가
    // * 이미지 이름 : tab_01_off / tab_01_on … (10번째부터 tab_10_off)
    let tabCode = "";
    for (let idx = 0; idx < count; idx++) {
      const num = String(idx + 1).padStart(2, "0");
      const className = [
        initOuterObj.isSwiper ? "swiper-slide" : "",
        "tab-btn",
        idx == 0 ? "on" : "",
      ]
        .filter(Boolean)
        .join(" ");

      tabCode += `
        <div class="${className}">
          <img src="${initOuterObj.imgPath}/tab/tab_${num}_off.${imgExtension}" alt="" />
          <img src="${initOuterObj.imgPath}/tab/tab_${num}_on.${imgExtension}" alt="" />
        </div>
      `;
    }

    ifTabCloneWrap.innerHTML = initOuterObj.isSwiper
      ? `
      <div class="tab-btn-area swiper-tab">
        <div class="swiper">
          <div class="swiper-wrapper">
            ${tabCode}
          </div>
        </div>
      </div>
      `
      : `
      <div class="tab-btn-area basic-tab">
            ${tabCode}
      </div>
      `;

    if (initOuterObj.isSwiper && !initOuterObj.swiperTab) {
      const tabBtnArea = ifTabCloneWrap.querySelector(".tab-btn-area");
      initOuterObj.isSwiperMove = false;

      // TODO 스와이프탭 백그라운드 설정
      // tabBtnArea.style.background = `url(${initOuterObj.imgPath}/tab/tab_bg.jpg) no-repeat center / cover`;
      tabBtnArea.style.background = "#000";

      // * Swiper 로드가 끝난 뒤 생성
      loadSwiper()
        .then(() => {
          initOuterObj.swiperTab = new Swiper(
            ".tab-btn-area.swiper-tab .swiper",
            {
              observer: true,
              observeParents: true,
              slidesPerView: "auto",
              freeMode: true,
              on: {
                setTranslate: function (swiper, translate) {
                  ifSlideTransform(translate);
                },
              },
            },
          );
        })
        .catch((error) => {
          console.error("[outer] 탭 Swiper 로드 실패", error);
        });
    }

    // * 복제 탭 클릭 (부모 페이지의 다른 .tab-btn과 섞이지 않도록 복제 탭 안에서만 찾음)
    ifTabCloneWrap.querySelectorAll(".tab-btn").forEach((element, idx) => {
      element.addEventListener("click", () => getTabClickAction(idx));
    });
  };
  // getIframeTabClone setting - 탭 복사 [E]

  // ! getTabClickAction - 탭 클릭 [S]
  const getTabClickAction = (idx) => {
    const winScrollTop = window.scrollY;
    let position = initOuterObj.tabAreaPosition[idx];
    const tabTop = Math.floor(initOuterObj.basicTopPosition + position);

    if (initOuterObj.deviceState == "pc") {
      const headerH = getPcHeaderH();
      const tabTopWithHeader = Math.floor(
        initOuterObj.basicTopPosition + position - headerH,
      );
      const isUp = document.body.classList.contains("up");
      const isDown = document.body.classList.contains("down");

      // *  pc 중복 클릭 return
      if (
        (isUp && isNearScroll(winScrollTop, tabTopWithHeader)) ||
        (isDown && isNearScroll(winScrollTop, tabTop))
      ) {
        return;
      }

      // * PC 스크롤 예외처리
      if (winScrollTop > tabTop || (isUp && winScrollTop > tabTopWithHeader)) {
        position = position - headerH;
      }
    } else {
      // * mo, app 중복 클릭 return
      if (winScrollTop == tabTop) {
        return;
      }
    }

    initOuterObj.isSwiperMove = true;

    setTimeout(() => {
      window.scrollTo({
        top: initOuterObj.basicTopPosition + position,
        behavior: "smooth",
      });
    }, 200);

    if (initOuterObj.isSwiper) {
      setTimeout(() => {
        initOuterObj.swiperTab?.slideTo(idx);
      }, 500);
    }

    sendToIframe("setTabTagging", { tabIdx: idx });
  };
  // getTabClickAction - 탭 클릭 [E]

  // ! cloneTabTopChange - 복사 탭 탑 위치값 수정 [S]
  const cloneTabTopChange = () => {
    const ifTabCloneWrap = document.querySelector(".if-tab-clone-wrap");

    if (ifTabCloneWrap) {
      setTimeout(() => {
        ifTabCloneWrap.style.top = `${
          document.querySelector(".snb").getBoundingClientRect().height
        }px`;
      }, 300);
    }
  };
  // cloneTabTopChange - 복사 탭 탑 위치값 수정 [E]

  // ! tabActive - 탭 활성화 [S]
  // * 현재 스크롤 위치에 해당하는 탭을 한 번만 계산해서 on 처리
  // * 탭 범위 : [탭 시작, 탭 시작 + 탭 높이)
  // *   PC 위로 스크롤 중이면 시작을 헤더 높이만큼 당기고, 정확히 탭 시작 위치는 제외 (기존 동작 그대로)
  // * 범위가 겹치면 뒤쪽 탭 우선 (기존 동작 그대로)
  const tabActive = (tabBtn, winScrollTop) => {
    if (initOuterObj.isTabActive == false) {
      return;
    }

    const isPcUp =
      initOuterObj.deviceState == "pc" &&
      document.body.classList.contains("up");
    const headerH = isPcUp ? getPcHeaderH() : 0;

    let activeIdx = -1;
    tabBtn.forEach((el, idx) => {
      const sectionHeight = initOuterObj.tabAreaHeight[idx];
      const sectionTop = Math.floor(
        initOuterObj.tabAreaPosition[idx] + initOuterObj.basicTopPosition,
      );

      if (
        winScrollTop >= sectionTop - headerH &&
        winScrollTop < sectionTop + sectionHeight &&
        !(isPcUp && winScrollTop == sectionTop)
      ) {
        activeIdx = idx;
      }
    });

    if (activeIdx < 0) return;

    tabBtn.forEach((el, idx) => {
      el.classList.toggle("on", idx === activeIdx);
    });

    if (
      initOuterObj.swiperTab &&
      initOuterObj.isSwiper &&
      !initOuterObj.isSwiperMove
    ) {
      initOuterObj.swiperTab.slideTo(activeIdx);
    }
  };
  // tabActive - 탭 활성화 [E]

  // ! targetMoveScrollAction setting - 타겟 위치 스크롤 이동 [S]
  const targetMoveScrollAction = (position) => {
    const winScrollTop = window.scrollY;

    if (initOuterObj.deviceState == "pc") {
      const headerH = getPcHeaderH();

      // * 중복 클릭 return
      if (
        (document.body.classList.contains("up") &&
          winScrollTop ==
            Math.floor(
              initOuterObj.basicTopPosition + position - headerH - 1,
            )) ||
        (document.body.classList.contains("down") &&
          winScrollTop == Math.floor(initOuterObj.basicTopPosition + position))
      ) {
        return;
      }

      // * PC 스크롤 예외처리
      if (
        winScrollTop > initOuterObj.basicTopPosition + position ||
        (document.body.classList.contains("up") &&
          winScrollTop > initOuterObj.basicTopPosition + position - headerH)
      ) {
        position = position - headerH;
      }
    } else {
      // * 중복 클릭 return
      if (
        winScrollTop == Math.floor(initOuterObj.basicTopPosition + position)
      ) {
        return;
      }
    }

    setTimeout(() => {
      window.scrollTo({
        top: initOuterObj.basicTopPosition + position,
        behavior: "smooth",
      });
    }, 200);
  };
  // targetMoveScrollAction setting - 타겟 위치 스크롤 이동 [E]

  // ! getModalWrapCreate setting - 모달 만들기 [S]
  const getModalWrapCreate = (modalImgPath, modalState, headerState) => {
    initOuterObj.modalImgPath = modalImgPath;

    if (modalState == "full") {
      headerState = "null";
    }

    const container = document.querySelector("#container");
    const ifModalWrap = document.createElement("div");

    ifModalWrap.classList.add("if-modal-wrap");
    container.prepend(ifModalWrap);

    let modalBasicCode = `
      <div class='if-modal-inner ${modalState}'>
        <div class='if-modal__header ${headerState}'>
          <div class="if-modal__close">
              <svg
                width="50"
                height="50"
                viewBox="0 0 50 50"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect
                  x="13.0815"
                  y="12.3744"
                  width="36"
                  height="1"
                  transform="rotate(45 13.0815 12.3744)"
                  fill="black"
                />
                <rect
                  x="38.5373"
                  y="13.0814"
                  width="36"
                  height="1"
                  transform="rotate(135 38.5373 13.0814)"
                  fill="black"
                />
              </svg>
            </div>
        </div>
        <div class='if-modal__container'></div>
      </div>
    `;

    ifModalWrap.innerHTML = modalBasicCode;

    // TODO modal css 설정
    if (initOuterObj.deviceState == "pc") {
      const ifModalHeader = document.querySelector(".if-modal__header");
      const ifModalClose = document.querySelector(".if-modal__close");

      // * headerState 없음(null / full 모드의 "null") : 20px, 있음 : 20px 0
      const hasHeaderState = headerState && headerState !== "null";
      ifModalHeader.style.padding = hasHeaderState ? "20px 0" : "20px";
      ifModalClose.style.cssText = `
        width: 60px;
        height: 60px;
      `;
    }

    // TODO modal css 설정
    if (initOuterObj.deviceState == "pc" && modalState != "full") {
      const ifModalInner = document.querySelector(".if-modal-inner");

      ifModalWrap.style.minWidth = "1200px";
      ifModalInner.style.maxWidth = "758px";
      ifModalInner.style.minHeight = "70%";
    }
  };
  // getModalWrapCreate setting - 모달 만들기 [E]

  // ! modalOpenAction - 모달 열기 설정 [S]
  const modalOpenAction = (content) => {
    const ifModalWrap = document.querySelector(".if-modal-wrap");
    const ifModalContainer = document.querySelector(".if-modal__container");

    // * 스와이퍼가 있으면 미리 로드 시작 (modalShow에서 로드 완료 후 생성)
    if (content.includes("swiper-mask")) {
      loadSwiper().catch(() => {});
    }

    ifModalContainer.innerHTML = content;

    // * modal link 분기 : 링크가 있으면 자식에게 링크 설정 요청
    if (content.includes("if-link-btn")) {
      ifModalContentEdit(content);
    }
    modalShow(content);

    ifModalWrap.removeEventListener("click", modalCloseAction);
    ifModalWrap.addEventListener("click", modalCloseAction);
  };
  // modalOpenAction - 모달 열기 설정 [E]

  // ! modalShow - 모달 show [S]
  const modalShow = (content) => {
    const ifModalWrap = document.querySelector(".if-modal-wrap");
    const ifModalContainer = document.querySelector(".if-modal__container");

    document.body.style.overflow = "hidden";
    setFixedBgModalLayer(true); // * 고정 배경 사용 시 모달이 헤더 위로 오도록
    ifModalWrap.style.display = "flex";
    ifModalContainer.scrollTop = 0;

    setTimeout(() => {
      // * modal swiper pc class 추가 & modal swiper prev button & next button background-image url 설정 & modal swiper 옵션 설정
      if (content.includes("swiper-mask")) {
        // * modal swiper pc class 추가
        if (initOuterObj.deviceState == "pc") {
          const swiperMask = ifModalWrap.querySelectorAll(".swiper-mask");

          swiperMask.forEach((element) => {
            element.classList.add("pc");
          });
        }

        const ifSwiperPrev = ifModalWrap.querySelectorAll(
          ".swiper-mask .swiper-button-prev",
        );
        const ifSwiperNext = ifModalWrap.querySelectorAll(
          ".swiper-mask .swiper-button-next",
        );

        // * modal swiper prev button & next button background-image url 설정
        // * NodeList는 항상 참이므로 length로 확인, 경로는 setImgPath로 받은 imgPath 사용
        // * (기존: 모달 첫 img src에서 잘라냄 → img가 없으면 에러)
        if (
          initOuterObj.imgPath &&
          (ifSwiperPrev.length || ifSwiperNext.length)
        ) {
          const cssImgPath = initOuterObj.imgPath;

          ifSwiperPrev.forEach((element) => {
            element.style.backgroundImage = `url(${cssImgPath}/slide_prev.png)`;
          });

          ifSwiperNext.forEach((element) => {
            element.style.backgroundImage = `url(${cssImgPath}/slide_next.png)`;
          });
        }

        // * modal swiper 옵션 설정 (Swiper 로드 완료 후 생성)
        loadSwiper()
          .then(() => {
            // * 모달 안의 스와이퍼만 (부모 페이지의 다른 .swiper-mask 제외)
            const swiperAll = ifModalWrap.querySelectorAll(".swiper-mask");

            // TODO swiper 옵션 설정
            // * 닫을 때 destroy 하도록 initOuterObj.modalSwipers에 저장
            swiperAll.forEach((element) => {
              const modalSwiper = new Swiper(element.querySelector(".swiper"), {
                observer: true,
                observeParents: true,

                pagination: {
                  el: element.querySelector(".swiper-pagination"),
                },
                navigation: {
                  nextEl: element.querySelector(".swiper-button-next"),
                  prevEl: element.querySelector(".swiper-button-prev"),
                },
                scrollbar: {
                  el: element.querySelector(".swiper-scrollbar"),
                },
              });
              initOuterObj.modalSwipers.push(modalSwiper);
            });
          })
          .catch((error) => {
            console.error("[outer] 모달 Swiper 로드 실패", error);
          });
      }

      ifModalWrap.style.opacity = "1";
    }, 500);
  };
  // modalShow - 모달 show [E]

  // ! modalCloseAction - 모달 닫기 설정 [S]
  // * 배경(모달 바깥) 또는 닫기 버튼(안의 svg 포함) 클릭 시 닫기
  // * (기존: 모든 svg/rect 클릭에 닫혀 콘텐츠 안 svg를 눌러도 닫혔음)
  const modalCloseAction = (e) => {
    const ifModalWrap = document.querySelector(".if-modal-wrap");
    const ifModalContainer = document.querySelector(".if-modal__container");

    const isCloseTarget =
      e.target === ifModalWrap || e.target.closest(".if-modal__close");
    if (!isCloseTarget) return;

    document.body.style.overflow = "auto";
    ifModalWrap.style.opacity = "0";
    setTimeout(() => {
      // * 모달 Swiper 정리 (observer 등 해제)
      initOuterObj.modalSwipers.forEach((swiper) => swiper.destroy(true, true));
      initOuterObj.modalSwipers = [];

      ifModalContainer.innerHTML = "";
      ifModalWrap.style.display = "none";
      setFixedBgModalLayer(false);
    }, 500);
  };
  // modalCloseAction - 모달 닫기 설정 [E]

  // ! getFixedBg - 고정 백그라운드 설정 [S]
  // TODO 배경 이미지 파일명 (images 폴더 기준)
  const FIXED_BG_IMG = "bg.png";

  // * MO · APP : iOS(앱 웹뷰 · Safari)는 background-attachment: fixed를 지원하지 않음
  // *   → 화면에 고정된 .fixed-bg를 깔고, container와 겹치는 부분만 clip-path로 보이게 함
  // *   → 스타일은 outer.css의 .fixed-bg
  // * PC · KIOSK : container에 background-attachment: fixed
  const fixedBgLayer = {
    el: null, // .fixed-bg
    container: null,
    rafId: null,
    isIsolated: false, // container에 isolate를 줬는지
  };

  // * 배경색 · 배경 이미지가 있는 요소인지
  const hasBackground = (element) => {
    const style = getComputedStyle(element);
    return (
      style.backgroundImage !== "none" ||
      !/^(transparent|rgba\(0, 0, 0, 0\))$/.test(style.backgroundColor)
    );
  };

  // * z-index:-1 배경을 가리는 요소가 있는지
  // *   - container ~ body 사이(container 포함)에 배경이 있으면 그 배경이 .fixed-bg를 덮음
  // *   - html · body 둘 다 배경이 있으면 body 배경이 화면 맨 아래로 내려가지 않아 덮음
  const isFixedBgCovered = (container) => {
    for (
      let el = container;
      el && el !== document.body;
      el = el.parentElement
    ) {
      if (hasBackground(el)) return true;
    }
    return (
      hasBackground(document.documentElement) && hasBackground(document.body)
    );
  };

  // * container와 화면이 겹치는 영역만 보이도록 clip-path 계산
  const updateFixedBgClip = () => {
    const { el, container } = fixedBgLayer;
    if (!el || !container) return;

    const rect = container.getBoundingClientRect();
    const bgRect = el.getBoundingClientRect(); // * .fixed-bg 자체 크기(화면 크기) 기준

    // * 화면과 container가 겹치지 않으면 전부 숨김
    if (
      rect.bottom <= bgRect.top ||
      rect.top >= bgRect.bottom ||
      rect.right <= bgRect.left ||
      rect.left >= bgRect.right
    ) {
      el.style.clipPath = "inset(100%)";
      return;
    }

    const top = Math.max(0, rect.top - bgRect.top);
    const right = Math.max(0, bgRect.right - rect.right);
    const bottom = Math.max(0, bgRect.bottom - rect.bottom);
    const left = Math.max(0, rect.left - bgRect.left);
    el.style.clipPath = `inset(${top}px ${right}px ${bottom}px ${left}px)`;
  };

  // * 스크롤 · 리사이즈가 연속으로 와도 프레임당 1번만 계산
  const requestFixedBgClip = () => {
    cancelAnimationFrame(fixedBgLayer.rafId);
    fixedBgLayer.rafId = requestAnimationFrame(updateFixedBgClip);
  };

  // * 고정 배경 레이어 만들기 : 한 번만 만들고, 다시 호출되면 이미지만 바꿈 (리스너 중복 방지)
  const createFixedBgLayer = (container, bgUrl) => {
    if (fixedBgLayer.el) {
      fixedBgLayer.el.style.backgroundImage = `url("${bgUrl}")`;
      updateFixedBgClip();
      return;
    }

    // * 배경을 가리는 요소가 있을 때만 container를 별도 stacking context로 만듦
    // *   → z-index:-1 배경이 container 배경 위 · 콘텐츠(iframe) 아래에 깔림
    // * 가리는 요소가 없으면 container를 건드리지 않음
    // *   → isolate하면 container가 z-index 없는 헤더보다 위에 그려지고,
    // *     안쪽 모달 · 복제 탭이 헤더 위로 올라가지 못하는 문제가 있어 꼭 필요할 때만 사용
    if (isFixedBgCovered(container)) {
      if (getComputedStyle(container).position === "static") {
        container.style.position = "relative";
      }
      container.style.isolation = "isolate";
      fixedBgLayer.isIsolated = true;
    }

    const el = document.createElement("div");
    el.className = "fixed-bg";
    el.style.backgroundImage = `url("${bgUrl}")`;
    container.appendChild(el);

    fixedBgLayer.el = el;
    fixedBgLayer.container = container;

    // * 스크롤 · 화면 크기 변경 대응 (iOS 주소창 접힘은 visualViewport로 감지)
    window.addEventListener("scroll", requestFixedBgClip, { passive: true });
    window.addEventListener("resize", requestFixedBgClip);
    if (window.visualViewport) {
      window.visualViewport.addEventListener("resize", requestFixedBgClip);
      window.visualViewport.addEventListener("scroll", requestFixedBgClip);
    }

    updateFixedBgClip(); // * 처음에는 바로 계산 (빈 화면 깜빡임 방지)
  };

  // * 모달 열림 · 닫힘 시 container 층 조정 (container를 isolate한 경우만)
  // * isolate된 container 안의 모달(z-index 1000)은 container 밖의 헤더보다 위로 올라가지 못함
  // * → 모달이 열려 있는 동안만 container를 모달 높이로 올림
  const setFixedBgModalLayer = (isOpen) => {
    if (!fixedBgLayer.isIsolated) return;
    fixedBgLayer.container.style.zIndex = isOpen ? "1000" : "";
  };

  const getFixedBg = () => {
    const container = document.querySelector("#container");
    // * container가 없거나 이미지 경로(setImgPath)를 받기 전이면 적용하지 않음
    if (!container || !initOuterObj.imgPath) return;

    const bgUrl = `${initOuterObj.imgPath}/${FIXED_BG_IMG}`;

    if (initOuterObj.deviceState == "mo" || initOuterObj.deviceState == "app") {
      createFixedBgLayer(container, bgUrl);
      return;
    }

    // * PC, KIOSK
    container.style.background = `url("${bgUrl}") no-repeat center 50% / cover`;
    container.style.backgroundAttachment = "fixed";
  };
  // getFixedBg - 고정 백그라운드 설정 [E]

  // ! getTabEndScroll - 마지막 탭 콘텐츠가 끝나는 스크롤 위치 [S]
  const getTabEndScroll = () => {
    const pos = initOuterObj.tabAreaPosition;
    const height = initOuterObj.tabAreaHeight;
    if (!pos || !pos.length) return Infinity;

    return initOuterObj.basicTopPosition + pos.at(-1) + height.at(-1);
  };
  // getTabEndScroll - 마지막 탭 콘텐츠가 끝나는 스크롤 위치 [E]

  // ! scrollAction - 스크롤 동작 [S]
  let scrollEndTimer = null;
  const scrollAction = () => {
    // ★ scrollLimits(85% 고정값) 삭제
    const winScrollTop = window.scrollY;
    const ifTabCloneWrap = document.querySelector(".if-tab-clone-wrap");

    if (initOuterObj.isSwiper) {
      clearTimeout(scrollEndTimer);
      scrollEndTimer = setTimeout(() => {
        initOuterObj.isSwiperMove = false;
      }, 100);
    }

    if (ifTabCloneWrap) {
      // * ACTIVE
      tabActive(ifTabCloneWrap.querySelectorAll(".tab-btn"), winScrollTop);

      const isPcUp =
        initOuterObj.deviceState == "pc" &&
        document.body.classList.contains("up");

      const headerH = isPcUp ? getPcHeaderH() : 0;

      // * 복제 탭이 나타나는 시작 위치 (기존 조건 그대로)
      const startScroll = Math.floor(
        initOuterObj.basicTopPosition +
          initOuterObj.tabBtnAreaPosition -
          headerH,
      );

      // ★ 마지막 탭 끝을 지나친 거리 (0보다 크면 그만큼 위로 밀어 올림)
      const overlap = winScrollTop + headerH - getTabEndScroll();
      const cloneH = ifTabCloneWrap.offsetHeight;

      // ★ 시작 위치 이후 ~ 복제 탭이 다 밀려 올라가기 전까지만 노출
      const isVisible = winScrollTop >= startScroll && overlap < cloneH;

      ifTabCloneWrap.style.visibility = isVisible ? "visible" : "hidden";
      ifTabCloneWrap.style.transform =
        isVisible && overlap > 0 ? `translateY(${-overlap}px)` : "";

      if (initOuterObj.isSwiper) {
        initOuterObj.isTabActive = isVisible;
      }

      // * 복제 탭 top 위치 (기존 동작 그대로)
      if (isPcUp) {
        ifTabCloneWrap.style.top = `${headerH}px`;
      } else if (document.body.classList.contains("down")) {
        ifTabCloneWrap.style.top = 0 + "px";
      }
    }
  };
  // scrollAction - 스크롤 동작 [E]

  let iframeReady = false;
  let loadInitFlag = false;
  // ! initFn : 초기화 함수 [S]
  const initFn = {
    loadInit: function () {
      if (!iframeReady) {
        setTimeout(function () {
          initFn.loadInit();
        }, 300);
        return;
      }

      if (!loadInitFlag) {
        loadInitFlag = true;

        getDeviceSet(); // 디바이스값 설정
        requestIframeHeight(); // iframe 높이값 요청
        getTabCloneData(); // 탭 복사 데이터 설정
        requestFixedBg(); // 고정 백그라운드 설정 요청 (fixedBg.js 있는 콘텐츠만 응답)
        if (initOuterObj.deviceState != "kiosk") {
          getBasicTop(); // 기본 탑 위치값 설정
          getTabValues(); // 탭 상세,탭 버튼 영역 높이값 & 탭 상세,탭 버튼 영역 위치값 설정
          getModalCreateData(); // 모달 만들기 데이터 설정
        }
      }
    },

    resizeInit: function () {
      requestIframeHeight(); // iframe 높이값 요청
      if (initOuterObj.deviceState != "kiosk") {
        getBasicTop(); // 기본 탑 위치값 설정
        getTabValues(); // 탭 상세,탭 버튼 영역 높이값 & 탭 상세,탭 버튼 영역 위치값 설정
      }
      if (
        initOuterObj.deviceState == "mo" ||
        initOuterObj.deviceState == "app"
      ) {
        cloneTabTopChange(); // 복사 탭 탑 위치값 수정
      }
      if (initOuterObj.deviceState != "kiosk") {
        scrollAction(); // 스크롤 동작
      }
    },
    scrollAction: function () {
      if (initOuterObj.deviceState != "kiosk") {
        scrollAction(); // 스크롤 동작
      }
    },
  };
  // initFn : 초기화 함수 [E]

  // ! window load, resize setting & scroll, visibilitychange action - 로드, 리사이즈 초기화 & 스크롤 동작 [S]
  if (document.readyState === "complete") {
    initFn.loadInit();
  } else {
    window.addEventListener("load", initFn.loadInit);
  }
  window.addEventListener("resize", initFn.resizeInit, { passive: true });
  window.addEventListener("scroll", initFn.scrollAction, { passive: true });
  window.addEventListener("visibilitychange", getIframeVisibilityChange);
  // window load, resize setting & scroll, visibilitychange action - 로드, 리사이즈 초기화 & 스크롤 동작 [E]

  // TODO ********************************************************************
  // TODO ********************************************************************
  // ! 1. search.js
  // ! 2. modal search.js
  // ! 3. pinch-zoom.js

  // ! 검색 작업
  // ! 모달 검색 작업
  // ! 핀치줌 작업
  // ! 기능 추가....
  // TODO ********************************************************************
  // TODO ********************************************************************
})();
