const LinkSetting = (element, type, newWindow, link_val) => {
  const filter = "win16|win32|win64|mac|macintel";

  let pcweb_url = "";
  let moweb_url = "";
  let app_url = "";

  if (type == "coupon") {
    pcweb_url = "https://www.lotteshopping.com/cpn/cpnDetail?cpnInfoNo=";
    moweb_url = "https://m.lotteshopping.com/cpn/cpnDetail?cpnInfoNo=";
    app_url = "lottecoupon://gate?page=a0026&cpnInfoNo=";
  } else if (type == "shopping") {
    pcweb_url =
      "https://www.lotteshopping.com/shpgnews/shpgnewsDetail?shpgNewsNo=";
    moweb_url =
      "https://m.lotteshopping.com/shpgnews/shpgnewsDetail?shpgNewsNo=";
    app_url = "lottecoupon://gate?page=a0083&shpgNewsNo=";
  } else if (type == "saeun") {
    pcweb_url = "https://www.lotteshopping.com/thku/thkuDetail?thkuNo=";
    moweb_url = "https://m.lotteshopping.com/thku/thkuDetail?thkuNo=";
    app_url = "lottecoupon://gate?page=a0065&thkuNo=";
  } else if (type == "event") {
    pcweb_url = "https://www.lotteshopping.com/cuterent/cuterentDetail?entNo=";
    moweb_url = "https://m.lotteshopping.com/cuterent/cuterentDetail?entNo=";
    app_url = "lottecoupon://gate?page=a0102&entNo=";
  } else if (type == "magazine") {
    pcweb_url =
      "https://www.lotteshopping.com/magazine/magazineDetail?mazinNo=";
    moweb_url = "https://m.lotteshopping.com/magazine/magazineDetail?mazinNo=";
    app_url = "lottecoupon://gate?page=a0086&mazinNo=";
  } else if (type == "shopnow") {
    pcweb_url = "https://www.lotteshopping.com/shopnow/cntsList?shpgHhlghNo=";
    moweb_url = "https://m.lotteshopping.com/shopnow/cntsList?shpgHhlghNo=";
    app_url =
      "lottecoupon://gate?page=a0137&url=https://m.lotteshopping.com/shopnow/cntsList?shpgHhlghNo=";
  } else if (type == "mallApp") {
    pcweb_url = "";
    moweb_url = "";
    app_url = "lottecoupon://gate?page=a0138&url=";
  } else if (type == "xBrowser") {
    pcweb_url = "";
    moweb_url = "";
    app_url = "lottecoupon://gate?page=a0240&url=";
  } else if (type == "xBrowserOld") {
    pcweb_url = "";
    moweb_url = "";
    app_url = "lottecoupon://gate?page=a0137&url=";
  } else if (type == "browserOpen") {
    pcweb_url = "";
    moweb_url = "";
    app_url = "lottecoupon://gate?page=a0168&url=";
  } else if (type == "browserOpenSkip") {
    pcweb_url = "";
    moweb_url = "";
    app_url = "lottecoupon://gate?page=a0258&url=";
  } else if (type == "xBrowserLang") {
    pcweb_url = "";
    moweb_url = "";
    app_url = "lottecouponglobal://gate?page=a0240&url=";
  } else if (type == "browserOpenLang") {
    pcweb_url = "";
    moweb_url = "";
    app_url = "lottecouponglobal://gate?page=a0168&url=";
  } else if (type == "login") {
    pcweb_url = "";
    moweb_url = "";
    app_url = "";
  }
  // else if (type == "BrowserOpen") {
  //   pcweb_url = "";
  //   moweb_url = "";
  //   app_url = "toapp:::AppViewMove:::BrowserOpen:::";
  // } else if (type == "xBrowser") {
  //   pcweb_url = "";
  //   moweb_url = "";
  //   // app_url = 'lottecoupon://gate?page=a0137&url=';
  //   app_url = "lottecoupon://gate?page=a0240&url=";
  // } else if (type == "sso") {
  //   pcweb_url = "";
  //   moweb_url = "";
  //   app_url = "lottecoupon://gate?page=a0138&ssoYn=Y&url=";
  //   // app_url = 'lottecoupon://gate?page=a0183&url=';
  // }

  if (newWindow != "yes" || newWindow != "no") {
    newWindow = "yes";
  }

  // if (initCommonObj.deviceState == 'pc') {
  //   element.href = `${pcweb_url}${link_val}`;
  //   if (newWindow == 'yes') {
  //     element.target = '_blank';
  //   }
  // } else if (initCommonObj.deviceState == 'mo') {
  //   element.href = `${moweb_url}${link_val}`;
  //   if (newWindow == 'yes') {
  //     element.target = '_blank';
  //   }
  // } else if (initCommonObj.deviceState == 'app') {
  //   element.href = `${app_url}${link_val}`;
  // }

  if (navigator.platform) {
    if (filter.indexOf(navigator.platform.toLowerCase()) >= 0) {
      // PCWEB 인 경우
      element.href = `${pcweb_url}${link_val}`;
      if (newWindow == "yes") {
        element.target = "_blank";
      }
    } else {
      var browserInfo = navigator.userAgent;
      var isInIFrame = window.location != window.parent.location;

      if (
        browserInfo.indexOf("LD_Android") > -1 ||
        browserInfo.indexOf("LD_iOS") > -1
      ) {
        // 앱 링크
        function encodeFullURL(url) {
          return encodeURIComponent(url).replace(/%20/g, "+"); // 필요 시 공백 처리 (선택사항)
        }

        if (type == "mallApp") {
          link_val = encodeFullURL(link_val);
        }

        element.href = `${app_url}${link_val}`;
      } else {
        // 모바일 웹 링크
        element.href = `${moweb_url}${link_val}`;
        if (newWindow == "yes") {
          element.target = "_blank";
        }
      }
    }
  }
};
