// *************************************************************************
// *************************************************************************
// * 2025.03.31 작업
// * 작업자 : 조윤상
// * version : v2.0 (2026.11.12 리팩토링 · 메시지 규격 v2)
// * outer.js와 자식 js는 반드시 같은 버전끼리 함께 배포
// *************************************************************************
// *************************************************************************

// TODO ********************************************************************
// ! postMessage 동작 - 받기
// TODO ********************************************************************

// ! parent window message receive - parent window에서 메세지 받기 [S]
// * 오디오 정지
onParentMessage('pageVisibilityChange', (param) => {
  audioStop(param && param.audioState);
});
// parent window message receive - parent window에서 메세지 받기 [E]

// TODO ********************************************************************
// ! iframe 내부 동작
// TODO ********************************************************************

// ! audioObj 세팅 [S]
// TODO 오디오 추가 시 element(박스) · audio(mp3) · color(진행바 색상)만 설정
const audioObj = [
  {
    id: 0,
    element: document.querySelector('.audio-box1'),
    audio: new Audio('https://minfo.lotteshopping.com/docentAudio/240411/yoon.mp3'),
    color: '#ffab8e',
    isPaused: true,
  },
  {
    id: 1,
    element: document.querySelector('.audio-box2'),
    audio: new Audio('https://minfo.lotteshopping.com/docentAudio/240411/joe.mp3'),
    color: '#ffab8e',
    isPaused: true,
  },
].filter((item) => item.element); // * 페이지에 박스가 없는 항목은 제외

// * 각 항목에 버튼 · 진행바 요소를 한 번만 찾아서 저장
audioObj.forEach((item) => {
  const audioBox = item.element;
  item.trackInput = audioBox.querySelector('input');
  item.audioCurrent = audioBox.querySelector('.audio-current');
  item.audioTotal = audioBox.querySelector('.audio-total');
  item.playBtn = audioBox.querySelector('.playBtn');
  item.pauseBtn = audioBox.querySelector('.pauseBtn');
});
// audioObj 세팅 [E]

// ! 오디오 재생 체크 - 재생/일시정지 버튼 표시 [S]
const playChk = (item) => {
  const isPlaying = !item.audio.paused;
  item.playBtn.style.display = isPlaying ? 'none' : 'block';
  item.pauseBtn.style.display = isPlaying ? 'block' : 'none';
};
// 오디오 재생 체크 - 재생/일시정지 버튼 표시 [E]

// ! 오디오 일시정지 [S]
const audioPause = (item) => {
  item.audio.pause();
  item.isPaused = true;
  playChk(item);
};
// 오디오 일시정지 [E]

// ! 오디오 재생 - 다른 오디오는 일시정지 [S]
const audioPlay = (item) => {
  item.audio.play();
  item.trackInput.disabled = false;
  item.isPaused = false;
  playChk(item);

  audioObj.forEach((other) => {
    if (other !== item) audioPause(other);
  });
};
// 오디오 재생 - 다른 오디오는 일시정지 [E]

// ! 오디오 업데이트 - 시간 · 진행바 [S]
const formatTime = (sec) => `${Math.floor((sec % 3600) / 60)} : ${String(sec % 60).padStart(2, '0')}`;

const timeUpdate = (item) => {
  const audio = item.audio;
  const total = Math.floor(audio.duration);
  const current = Math.floor(audio.currentTime);

  item.audioCurrent.innerHTML = formatTime(current);
  item.audioTotal.innerHTML = formatTime(total);

  const progress = (audio.currentTime / audio.duration) * 100;
  item.trackInput.style.background = `linear-gradient(to right, ${item.color} ${progress}%, rgba(136, 136, 136, 0.2) ${progress}%)`;

  playChk(item);

  // * 끝까지 재생되면 정지 상태로
  if (total === current) {
    item.isPaused = true;
  }
};
// 오디오 업데이트 - 시간 · 진행바 [E]

// ! 화면 이동 시, 오디오 일시 정지 [S]
// * tab.js(키오스크 탭 이동), 부모 pageVisibilityChange 에서 호출
// TODO APP, KIOSK 에서 확인 필요!!
const audioStop = (audioState) => {
  audioObj.forEach((item) => {
    item.audio.pause();
    item.isPaused = audioState;
    playChk(item);
  });
};
// 화면 이동 시, 오디오 일시 정지 [E]

// ! 오디오 이벤트 [S]
// * 진행바를 놓으면 재생 중이던 오디오만 다시 재생
const resumePlaying = () => {
  audioObj.forEach((item) => {
    if (item.isPaused === false) item.audio.play();
  });
};

audioObj.forEach((item) => {
  const { audio, trackInput, playBtn, pauseBtn } = item;

  audio.addEventListener('loadedmetadata', () => {
    trackInput.max = audio.duration;
    timeUpdate(item);

    setDataInit();
  });

  audio.ontimeupdate = () => {
    trackInput.value = audio.currentTime;
    timeUpdate(item);
  };

  playBtn.addEventListener('click', () => audioPlay(item));
  pauseBtn.addEventListener('click', () => audioPause(item));

  trackInput.addEventListener('input', () => {
    audio.currentTime = trackInput.value;
    timeUpdate(item);
  });

  trackInput.addEventListener('mousedown', () => audio.pause());
  trackInput.addEventListener('mouseup', resumePlaying);
  trackInput.addEventListener('touchstart', () => audio.pause(), { passive: true });
  trackInput.addEventListener('touchend', resumePlaying, { passive: true });
});
// 오디오 이벤트 [E]
