// *************************************************************************
// *************************************************************************
// * 2025.03.31 작업
// * 작업자 : 조윤상
// * version : v2.0 (2026.11.12 리팩토링 · 메시지 규격 v2)
// * outer.js와 자식 js는 반드시 같은 버전끼리 함께 배포
// *************************************************************************
// *************************************************************************

// ! sendToParent - 부모로 메세지 보내기 [S]
// * 모든 자식 → 부모 메세지는 이 함수로만 보낸다 (tab.js, modal.js 등도 사용)
// * function 선언으로 두어 파일 어디서든 먼저 호출 가능
function sendToParent(fnNm, param) {
  const data = param === undefined ? { fnNm } : { fnNm, param };
  window.parent.postMessage(data, "*");
}
// sendToParent - 부모로 메세지 보내기 [E]

// ! onParentMessage - 부모 메세지 처리 등록 [S]
// * 각 파일(common, tab, modal, audio …)은 리스너를 직접 달지 않고 여기에 등록한다
// * 같은 fnNm에 여러 처리를 등록하면 등록한 순서대로 실행
const parentMessageHandlers = {};

function onParentMessage(fnNm, handler) {
  if (!parentMessageHandlers[fnNm]) {
    parentMessageHandlers[fnNm] = [];
  }
  parentMessageHandlers[fnNm].push(handler);
}

window.addEventListener("message", (message) => {
  // * 부모 창이 보낸 메세지만 처리
  if (message.source !== window.parent) return;

  const data = message.data;
  if (!data || !data.fnNm) return;

  const handlers = parentMessageHandlers[data.fnNm] || [];
  handlers.forEach((handler) => handler(data.param));
});
// onParentMessage - 부모 메세지 처리 등록 [E]

let outerReady = false;
// ! ping - 부모 준비 확인 [S]
// * 부모(outer.js)가 outerReady로 응답할 때까지 300ms마다 iframeReady 전송
// * 최대 100회(약 30초) 후에도 응답이 없으면 중단 (단독 실행 시 무한 반복 방지)
const PING_INTERVAL = 300;
const PING_MAX_COUNT = 100;
let pingCount = 0;

window.addEventListener("load", function () {
  ping();
});

function ping() {
  if (outerReady) {
    return;
  }

  if (pingCount >= PING_MAX_COUNT) {
    console.warn("[common] 부모 페이지 응답 없음 - iframeReady 전송 중단");
    return;
  }

  pingCount++;
  sendToParent("iframeReady");

  setTimeout(function () {
    if (!outerReady) {
      ping();
    }
  }, PING_INTERVAL);
}
// ping - 부모 준비 확인 [E]

onParentMessage("outerReady", () => {
  setImgPath();
  outerReady = true;
});

// TODO ********************************************************************
// ! 전역 변수
// TODO ********************************************************************

const iframeHtml = document.querySelector("html");
// * 실행 중 추가되는 값 : deviceState, iframeHeight, basePath, imgPath, isSwiper
const initCommonObj = {
  isIframeHeight: false,
  tabAreaHeight: [],
  tabAreaPosition: [],
  tabBtnAreaHeight: 0,
  tabBtnAreaPosition: 0,
  isTabValues: false,
};

// TODO ********************************************************************
// ! postMessage 동작 - 보내기
// TODO ********************************************************************

// ! setImgPath - 이미지 경로 설정 [S]
const setImgPath = () => {
  if (window.__SET_IMG_PATH_CALLED__) return;
  window.__SET_IMG_PATH_CALLED__ = true;

  const imgTag = document.querySelector("img");

  // * img 태그가 없으면 현재 문서 위치 기준으로 경로 계산
  const src = imgTag
    ? imgTag.src
    : `${location.href.substring(0, location.href.lastIndexOf("/"))}/images/`;

  let basePath = src.substring(0, src.indexOf("/images"));

  if (src.includes("http://127.0.0.1")) {
    // * local 유지
  } else if (src.includes("http://124.243.59.42:9094")) {
    // * 개발기
    basePath = basePath.replace(
      window.location.host,
      "minfo.lotteshopping.com",
    );
  } else if (src.includes("global")) {
    // * 다국어
    basePath = src.includes("https://m.global.")
      ? basePath.replace("https://m.global.", "https://minfo.")
      : basePath.replace("https://global.", "https://minfo.");
  } else {
    // * 국문
    basePath = src.includes("https://m.")
      ? basePath.replace("https://m.", "https://minfo.")
      : basePath.replace("https://www.", "https://minfo.");
  }

  const imgPath = `${basePath}/images`;
  initCommonObj.basePath = basePath;
  initCommonObj.imgPath = imgPath;

  sendToParent("setImgPath", {
    basePath,
    imgPath,
  });
};
// setImgPath - 이미지 경로 설정 [E]

// ! 높이 무한 반복 안전장치 [S]
// * 콘텐츠에 vh / height:100% 등을 쓰면 [iframe 높이 변경 → 콘텐츠 높이 변경]이 무한 반복될 수 있음
// * 아래 조건이면 높이 전송과 자동 감지를 중단하고 콘솔에 경고
// *   - 3초 안에 높이 전송이 100회를 넘을 때 (토글·애니메이션은 이 안에 들지 않음)
// *   - 콘텐츠 높이가 100,000px을 넘을 때
const HEIGHT_LIMIT_COUNT = 100; // 3초 안에 100회 초과
const HEIGHT_LIMIT_TIME = 3000; // 또는 높이 100,000px 초과
const HEIGHT_LIMIT_PX = 100000;

let heightSendHistory = [];
let isHeightStopped = false;

const checkHeightLoop = (height) => {
  const now = Date.now();
  heightSendHistory = heightSendHistory.filter(
    (time) => now - time < HEIGHT_LIMIT_TIME,
  );
  heightSendHistory.push(now);

  let reason = "";
  if (height > HEIGHT_LIMIT_PX) {
    reason = `콘텐츠 높이 ${Math.round(height)}px`;
  } else if (heightSendHistory.length > HEIGHT_LIMIT_COUNT) {
    reason = `${HEIGHT_LIMIT_TIME / 1000}초 안에 높이 변경 ${HEIGHT_LIMIT_COUNT}회 초과`;
  }

  if (reason) {
    isHeightStopped = true;
    stopObserveContentSize();
    console.warn(
      `[common] iframe 높이 전송 중단 - ${reason} (콘텐츠에 vh 단위나 height:100% 사용 여부 확인)`,
    );
    return true;
  }
  return false;
};
// 높이 무한 반복 안전장치 [E]

// ! setDataInit setting - 데이터 초기화 메세지 보내기 [S]
const setDataInit = () => {
  // * 부모 요청 전이거나 안전장치가 걸렸으면 보내지 않음
  // * iframe 높이값 설정 (부모 요청 전, 안전장치 동작 후에는 보내지 않음)
  if (!initCommonObj.isIframeHeight || isHeightStopped) return;

  const height = iframeHtml.getBoundingClientRect().height;
  if (initCommonObj.iframeHeight == height) return; // 같으면 안 보냄
  if (checkHeightLoop(height)) return; // 폭주면 중단

  initCommonObj.iframeHeight = height;
  sendToParent("iframeHeight", { height });
};
setDataInit();
// setDataInit setting - 데이터 초기화 메세지 보내기 [E]

// ! observeContentSize - 콘텐츠 크기 변화 자동 감지 [S]
// * body 크기가 바뀌면 자동으로 높이(setDataInit) · 탭 위치(setTabDataInit)를 부모에 전송
// * 토글, 서브탭, 이미지 지연 로드 등 높이가 바뀌는 곳에서 따로 호출하지 않아도 됨
// * ResizeObserver 미지원 브라우저는 기존 수동 호출로 그대로 동작
let resizeObserver = null;
let resizeRafId = null;

const stopObserveContentSize = () => {
  if (!resizeObserver) return;
  resizeObserver.disconnect();
  resizeObserver = null;
};

const observeContentSize = () => {
  // * 미지원 브라우저는 기존 수동 호출로 동작
  if (!("ResizeObserver" in window) || resizeObserver) return;

  resizeObserver = new ResizeObserver(() => {
    // * 연속 호출은 프레임당 1회로 묶음
    cancelAnimationFrame(resizeRafId);
    resizeRafId = requestAnimationFrame(() => {
      if (!resizeObserver) return;

      setDataInit(); // 높이
      if (typeof setTabDataInit === "function") {
        setTabDataInit(); // 탭 위치 (tab.js 있을 때만)
      }
    });
  });

  resizeObserver.observe(document.body);
};
observeContentSize();
// observeContentSize - 콘텐츠 크기 변화 자동 감지 [E]

// ! targetMoveScroll setting - 타겟 위치 스크롤 이동 [S]
const targetMoveScroll = (target) => {
  const tabBtnArea = document.querySelector(".tab-btn-area");

  sendToParent("targetMoveScroll", {
    targetPosition: tabBtnArea
      ? target.getBoundingClientRect().top -
        tabBtnArea.getBoundingClientRect().height
      : target.getBoundingClientRect().top,
  });
};
// targetMoveScroll setting - 타겟 위치 스크롤 이동 [E]

// TODO ********************************************************************
// ! postMessage 동작 - 받기
// TODO ********************************************************************

// ! parent window message receive - parent window에서 메세지 받기 [S]
// * 디바이스값 설정
const DEVICE_STATES = ["pc", "mo", "app", "kiosk"];
onParentMessage("setDevice", (param) => {
  if (param && param.deviceState) {
    // * deviceState 따른 기본 동작 : .pcDel / .moDel / .appDel / .kioskDel 요소 삭제
    if (DEVICE_STATES.includes(param.deviceState)) {
      elDel(`${param.deviceState}Del`);
    }

    initCommonObj.deviceState = param.deviceState;
  }
});

// * iframe 높이값 요청
onParentMessage("requestIframeHeight", () => {
  // * 높이가 그대로면 응답하지 않음 (부모와 무한 반복 방지)
  if (initCommonObj.iframeHeight == iframeHtml.getBoundingClientRect().height) {
    return;
  }

  initCommonObj.isIframeHeight = true;
  setDataInit();
});
// parent window message receive - parent window에서 메세지 받기 [E]

// TODO ********************************************************************
// ! iframe 내부 동작
// TODO ********************************************************************

// ! 태깅 [S]
// * 2023.11.09 수정
const APP_EVENT = (label, addInfo, type) => {
  // <!-- ! lable : 버튼명, addInfo : 이벤트 부가정보 -->
  ga4Event.event(
    "click_event",
    "APP_쇼핑뉴스상세",
    "하단버튼",
    label,
    addInfo,
    "",
    `${type == "sso" ? "Y" : "N"}`,
  );
};

const tg = () => {
  const linkAll = document.querySelectorAll(".link-btn");

  if (linkAll && linkAll.length > 0) {
    linkAll.forEach((element) => {
      const idx = element.dataset.order;

      element.onclick = () => {
        APP_EVENT(
          linkObj[idx].value,
          `${contentName}_${contentCode}`,
          linkObj[idx].type,
        );
      };

      const url = linkObj[idx].url.trim();

      LinkSetting(element, linkObj[idx].type, "yes", url);
    });
  }
};
setTimeout(() => {
  tg();
}, 500);
// 태깅 [E]

// ! toggle-box - 토글 박스 [S]
const toggleAction = (e) => {
  e.target.closest(".toggle-box").classList.toggle("on");
  // setDataInit();

  // if (document.querySelector(".tab-btn-area")) {
  //   setTabDataInit();
  // }
};

const toggleBtn = document.querySelectorAll(".toggle-box__btns");
toggleBtn.forEach((element) => {
  element.addEventListener("click", toggleAction);
});
// toggle-box - 토글 박스 [E]

// ! copy - 복사 [S]
// * currentTarget : .copy-btn 안의 이미지 등을 눌러도 버튼의 data-text 사용
// * 복사가 실제로 끝난 뒤 알림 (iframe은 allow="clipboard-write" 필요)
const copyAction = (e) => {
  const text = e.currentTarget.dataset.text;

  if (!navigator.clipboard) {
    console.warn("[common] 클립보드 사용 불가 (https 또는 iframe allow 확인)");
    return;
  }

  navigator.clipboard
    .writeText(text)
    .then(() => window.alert("복사되었습니다."))
    .catch((error) => console.warn("[common] 복사 실패", error));
};

const copyBtn = document.querySelectorAll(".copy-btn");
copyBtn.forEach((element) => {
  element.addEventListener("click", copyAction);
});
// copy - 복사 [E]

// ! elDel - 엘리먼트 삭제 [S]
const elDel = (className) => {
  document
    .querySelectorAll(`.${className}`)
    .forEach((element) => element.remove());
};
// elDel - 엘리먼트 삭제 [E]

// TODO ********************************************************************
// TODO ********************************************************************
// ! 1. search.js
// ! 2. modal search.js
// ! 3. pinch-zoom.js

// ! 검색 작업
// ! 모달 검색 작업
// ! 핀치줌 작업
// ! 기능 추가....
// TODO ********************************************************************
// TODO ********************************************************************
