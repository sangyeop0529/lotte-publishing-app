$(document).ready(function () {
  // 데이터 컨텐츠 영역
  const dataContents = {
    "Luxury & Contemporary": $(".box-1 .category-body"),
    Fashion: $(".box-2 .category-body"),
    "Golf / Sports & Outdoor": $(".box-3 .category-body"),
    Acc: $(".box-4 .category-body"),
    Kids: $(".box-5 .category-body"),
    "Living & Lifestyle": $(".box-6 .category-body"),
  };

  // 검색 관련 요소들
  const search = $("#search");
  const searchResultWrap = $("#search-result-wrap");
  const searchResultWrapClone = $("#search-result-wrap-clone");
  const searchResult = $("#search-result");
  const searchResultClone = $("#search-result-clone");

  let clickSearchArr = [];
  let cloneStat = 0;

  // 브랜드 데이터에 고유 숫자 ID 추가
  function createBrandId() {
    let idCounter = 1;
    Object.keys(brandData).forEach((category) => {
      const brands = brandData[category];
      brands.forEach((brand) => {
        if (!brand.id) {
          brand.id = idCounter++;
        }
      });
    });
  }

  // 초기 렌더링
  function initializeBrandDisplay() {
    // ID 추가
    createBrandId();

    // 각 할인률별로 브랜드 렌더링
    Object.keys(brandData).forEach((category) => {
      const brands = brandData[category];
      const groupedBrands = groupBrandsByCategory(brands);

      Object.keys(groupedBrands).forEach((percent) => {
        const percentBrands = groupedBrands[percent];
        if (percentBrands.length > 0) {
          const percentHtml = createPercentSection(
            category,
            percentBrands,
            percent,
          );
          dataContents[category].append(percentHtml);
        }
      });
    });
  }

  // 할인율 섹션 생성
  function createPercentSection(category, brands, percent) {
    const percentNumber = percent.replace("%", "");
    const percentHtml = `
          <div class="percent-section">
              <h3 class="percent-title">
                <img src="./images/tab1/${percentNumber}.png" alt="" />
              </h3>
              
                  <div class="brand-list">
                    ${brands
                      .map(
                        (brand) => `
                        <div class="result result-${brand.id}">
                          <span class="brand-name">${brand.name}</span><span class="comma">,</span>
                        </div>
                        ${brand.lineBreak ? "<br />" : ""}
                      `,
                      )
                      .join("")}
                    </div>
                    ${
                      percent === "30%" &&
                      category === "Golf / Sports & Outdoor"
                        ? `<img src="./images/tab1/nike.jpg" alt="" class="" />`
                        : ""
                    }
                  </div>
              </div>
          </div>
      `;
    return percentHtml;
  }

  // 검색 기능 초기화
  function initializeSearch() {
    allBrands.forEach((brand) => {
      const searchBtnHTML = `
          <div class="scroll-btn scroll-btn-${brand.id}" data-brand-name="${brand.name}">
            <div><span class="brand-name">${brand.name}</span></div>
          </div>
        `;

      const $searchBtn = $(searchBtnHTML);
      searchResult.append($searchBtn);
      searchResultClone.append($searchBtn.clone(true));

      // 스크롤 이동 이벤트 (기본 리스트)
      $searchBtn.on("click", function () {
        handleSearchResultClick(brand);
      });
    });

    // Clone 리스트에도 이벤트 재바인딩
    $(document).on("click", ".scroll-btn", function () {
      const brandName = $(this).data("brand-name");
      const matchingBrand = allBrands.find((brand) => brand.name === brandName);
      if (matchingBrand) {
        handleSearchResultClick(matchingBrand);
      }
    });
  }

  // 동일 브랜드명의 목록 항목 조회
  function getResultsByBrandName(brandName) {
    return $(".category-body .brand-list .result").filter(function () {
      return $(this).find(".brand-name").text() === brandName;
    });
  }

  // 검색 결과 클릭 핸들러 함수
  function handleSearchResultClick(brand) {
    const brandName = brand.name;

    // 검색 결과 영역 숨기기
    searchResultWrapClone.hide();
    searchResultWrap.hide();
    resultActive(brandName);
    cloneStat = 0; // cloneStat 리셋

    // 스크롤 이동 — 동명 브랜드는 상단(첫 번째) 항목으로
    setTimeout(() => {
      const $targets = getResultsByBrandName(brandName);

      if ($targets.length > 0) {
        $targets.first()[0].scrollIntoView({
          behavior: "smooth",
          block: "center",
          inline: "nearest",
        });
      } else {
        console.warn(`Target element for brand "${brandName}" not found`);
      }
    }, 300);
  }

  // 검색 필터링
  function filter() {
    const value = search.val();
    const resultNone = document.querySelector(".result-none");
    let resultArr = [];

    $("#search-result-wrap .scroll-btn").each(function () {
      const matched = $(this).text().includes(value) && value !== "";
      $(this).css("display", matched ? "flex" : "none");
      if (matched) resultArr.push(this);
    });

    $("#search-result-wrap-clone .scroll-btn").each(function () {
      const matched = $(this).text().includes(value) && value !== "";
      $(this).css("display", matched ? "flex" : "none");
    });

    clickSearchArr = resultArr;

    if (value.length === 0 || value === "") {
      searchResultWrap.hide(); // 검색 결과 영역 숨기기
      resultNone.style.display = "none";
    } else if (value.length !== 0 && resultArr.length === 0) {
      resultNone.style.display = "flex";
    } else {
      resultNone.style.display = "none";
    }
  }

  // 검색 이벤트
  search.on("focus", function () {
    searchResultWrap.css({ opacity: "1", display: "block" });
    // search-wrap에 포커스가 되면 clone 요소를 숨김
    // searchResultWrapClone.hide();
    cloneStat = 0;
  });

  search.on("blur", function () {
    searchResultWrap.css("opacity", "0");
    setTimeout(() => {
      searchResultWrap.hide();
    }, 500);
  });

  $(".search-i").on("click", function (e) {
    e.preventDefault();
    const searchValue = search.val();
    cloneStat = 0;

    if (searchValue.length === 0) {
      alert("브랜드명을 입력해주세요");
    } else if (clickSearchArr.length === 0) {
      alert("검색 결과가 없습니다");
    } else if (clickSearchArr.length === 1) {
      const brandName = $(clickSearchArr[0]).data("brand-name");
      const matchingBrand = allBrands.find((brand) => brand.name === brandName);

      if (matchingBrand) {
        handleSearchResultClick(matchingBrand);
        search.blur();
      }
    } else if (
      [...new Set(clickSearchArr.map((el) => $(el).data("brand-name")))]
        .length === 1
    ) {
      const brandName = $(clickSearchArr[0]).data("brand-name");
      const matchingBrand = allBrands.find((brand) => brand.name === brandName);

      if (matchingBrand) {
        handleSearchResultClick(matchingBrand);
        search.blur();
      }
    } else {
      alert("검색 결과 리스트에서 브랜드를 클릭해주세요");
      setTimeout(() => {
        cloneStat = 1;
        searchResultWrapClone.show();
      }, 100);
    }
  });

  // 결과 활성화 (이전 선택 스타일 초기화 후 현재 브랜드만 강조)
  function resetResultActive() {
    $(".category-body .brand-list .result.is-active").removeClass("is-active");
  }

  function resultActive(brandName) {
    resetResultActive();
    getResultsByBrandName(brandName).addClass("is-active");
    searchResultWrap.hide();
  }

  // 전역 필터 함수 등록
  window.filter = filter;

  // 초기화 실행
  initializeBrandDisplay();
  initializeSearch();

  // 각 brand-list의 마지막 result 요소에서 comma 제거
  $(".brand-list").each(function () {
    const lastItem = $(this).find(".result").last();
    lastItem.find(".comma").remove();
  });
});
