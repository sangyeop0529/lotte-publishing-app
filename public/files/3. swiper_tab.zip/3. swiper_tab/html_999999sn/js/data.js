// 가나다 순 정렬 함수 (priorityNames에 있는 브랜드는 맨 앞에 고정)
function sortBrandsByName(brands, priorityNames = []) {
  brands.sort((a, b) => {
    const aIdx = priorityNames.indexOf(a.name);
    const bIdx = priorityNames.indexOf(b.name);

    // 둘 다 우선 브랜드: 지정한 순서대로
    if (aIdx !== -1 && bIdx !== -1) return aIdx - bIdx;
    // a만 우선 브랜드: a를 앞으로
    if (aIdx !== -1) return -1;
    // b만 우선 브랜드: b를 앞으로
    if (bIdx !== -1) return 1;

    // 나머지는 가나다순
    return a.name.localeCompare(b.name, "ko-KR");
  });

  // 우선 브랜드 중 마지막 항목 뒤에서 줄바꿈
  const lastPriority = brands
    .filter((brand) => priorityNames.includes(brand.name))
    .pop();
  if (lastPriority) lastPriority.lineBreak = true;

  return brands;
}

const brandData = {
  "Luxury & Contemporary": sortBrandsByName([
    { name: "듀퐁슈즈", salesRate: "20%" },
    { name: "띠어리(10/30~11/1)", salesRate: "20%" },
    { name: "랙앤본(10/30~11/1)", salesRate: "20%" },
    { name: "마쥬(10/30~11/1)", salesRate: "20%" },
    { name: "메종키츠네(10/30~11/1)", salesRate: "20%" },
    { name: "비이커(10/30~11/1)", salesRate: "20%" },
    { name: "산드로(10/30~11/1)", salesRate: "20%" },
    { name: "슬로웨어(10/30~11/1)", salesRate: "20%" },
    { name: "쟈딕앤볼테르", salesRate: "20%" },
    { name: "준지(10/30~11/1)", salesRate: "20%" },
    { name: "준지여성(10/30~11/1)", salesRate: "20%" },

    { name: "빔바이롤라", salesRate: "10%" },
    { name: "송지오옴므", salesRate: "10%" },
    { name: "씨피컴퍼니(11/6~8)", salesRate: "10%" },
    { name: "올세인츠", salesRate: "10%" },
    { name: "파비아나필리피", salesRate: "10%" },
    { name: "휴고보스(100만원 이상 구매시)", salesRate: "10%" },
    { name: "FGF(11/6~8)", salesRate: "10%" },
  ]),
  Fashion: sortBrandsByName([
    { name: "게스언더웨어", salesRate: "30%" },
    { name: "룩캐스트", salesRate: "30%" },
    { name: "샤틴", salesRate: "30%" },
    { name: "엠씨", salesRate: "30%" },
    { name: "코데즈컴바인 이너웨어", salesRate: "30%" },
    { name: "프로젝트엠", salesRate: "30%" },

    { name: "갤럭시(10/30~11/1)", salesRate: "20%" },
    { name: "게스(2pcs 이상 구매시)", salesRate: "20%" },
    { name: "구호(10/30~11/1)", salesRate: "20%" },
    { name: "기비앤키이스(10/30~11/1)", salesRate: "20%" },
    { name: "나이스클랍", salesRate: "20%" },
    { name: "더틸버리", salesRate: "20%" },
    { name: "데무", salesRate: "20%" },
    { name: "데코", salesRate: "20%" },
    { name: "듀엘(10~20%)", salesRate: "20%" },
    { name: "라코스테(10/30~11/1)", salesRate: "20%" },
    { name: "레노마맨", salesRate: "20%" },
    { name: "레노마셔츠", salesRate: "20%" },
    { name: "로가디스(10/30~11/1)", salesRate: "20%" },
    { name: "르베이지(10/30~11/1)", salesRate: "20%" },
    { name: "리스트", salesRate: "20%" },
    { name: "린(10/30~11/4, 11/5~15)", salesRate: "20%" },
    { name: "모에", salesRate: "20%" },
    { name: "미니멈", salesRate: "20%" },
    { name: "버커루", salesRate: "20%" },
    { name: "보니스팍스", salesRate: "20%" },
    { name: "보브", salesRate: "20%" },
    { name: "빈폴", salesRate: "20%" },
    { name: "쉬즈미스", salesRate: "20%" },
    { name: "안지크", salesRate: "20%" },
    { name: "에고이스트", salesRate: "20%" },
    { name: "올리브데올리브", salesRate: "20%" },
    { name: "올앤선드리", salesRate: "20%" },
    { name: "제이제이지고트", salesRate: "20%" },
    { name: "주크", salesRate: "20%" },
    { name: "지프", salesRate: "20%" },
    { name: "캐리스노트", salesRate: "20%" },
    { name: "캘빈클라인진/언더", salesRate: "20%" },
    { name: "크레송", salesRate: "20%" },
    { name: "톰보이/스튜디오톰보이", salesRate: "20%" },
    { name: "헌치", salesRate: "20%" },
    { name: "BCBG", salesRate: "20%" },
    { name: "CK언더웨어", salesRate: "20%" },
    { name: "SSF(10/30~11/1)", salesRate: "20%" },

    { name: "뉴에라", salesRate: "10%" },
    { name: "닥스(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "더블제이디", salesRate: "10%" },
    { name: "더아이잗", salesRate: "10%" },
    { name: "드로우핏", salesRate: "10%" },
    { name: "럭키슈에뜨", salesRate: "10%" },
    { name: "르니앤맥코이(11/6~8)", salesRate: "10%" },
    { name: "리버클래시", salesRate: "10%" },
    { name: "리본", salesRate: "10%" },
    { name: "마에스트로(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "마인드브릿지(5%)", salesRate: "10%" },
    { name: "마크곤잘레스", salesRate: "10%" },
    { name: "맨잇슈트", salesRate: "10%" },
    { name: "모조", salesRate: "10%" },
    { name: "바네사브루노(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "바버(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "바쏘", salesRate: "10%" },
    { name: "바인드", salesRate: "10%" },
    { name: "발렌시아", salesRate: "10%" },
    { name: "베네통", salesRate: "10%" },
    { name: "빈스(라움 10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "빨질레리", salesRate: "10%" },
    { name: "세터(2pcs 이상 구매시)", salesRate: "10%" },
    { name: "슈퍼드라이(2pcs 이상 구매시)", salesRate: "10%" },
    { name: "시리즈", salesRate: "10%" },
    { name: "시슬리", salesRate: "10%" },
    { name: "아이잗바바(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "아이잗컬렉션(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "알레그리(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "앤드지", salesRate: "10%" },
    { name: "예작", salesRate: "10%" },
    { name: "온앤온", salesRate: "10%" },
    { name: "요하넥스", salesRate: "10%" },
    { name: "웰메이드", salesRate: "10%" },
    { name: "지고트(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "지오송지오", salesRate: "10%" },
    { name: "지이크", salesRate: "10%" },
    { name: "진도모피", salesRate: "10%" },
    { name: "질스튜어트(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "질스튜어트뉴욕(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "쁘렝땅", salesRate: "10%" },
    { name: "캠브리지멤버스", salesRate: "10%" },
    { name: "커스텀멜로우", salesRate: "10%" },
    { name: "파렌", salesRate: "10%" },
    { name: "페라로밀라노", salesRate: "10%" },
    { name: "펜필드", salesRate: "10%" },
    { name: "플리츠미", salesRate: "10%" },
    { name: "헤지스(10/30~11/1, 11/6~8)", salesRate: "10%" },
    { name: "후아유", salesRate: "10%" },
  ]),
  "Golf / Sports & Outdoor": sortBrandsByName(
    [
      { name: "나이키", salesRate: "30%" },
      { name: "뉴발란스", salesRate: "30%" },
      { name: "반스(신발 3족 이상 구매시)", salesRate: "30%" },
      { name: "아디다스", salesRate: "30%" },
      { name: "언더아머(직영/카카오톡 친구 추가시)", salesRate: "30%" },
      { name: "에스마켓", salesRate: "30%" },
      { name: "컨버스(성한)", salesRate: "30%" },
      { name: "컬럼비아", salesRate: "30%" },
      { name: "크록스(코리아, 주말 2족 이상 구매시)", salesRate: "30%" },
      { name: "휠라(3PCS 이상 구매시)", salesRate: "30%" },
      { name: "HDEX(10/20~11/1)", salesRate: "30%" },

      { name: "네파(멤버십 가입 고객 대상)", salesRate: "20%" },
      { name: "데상트골프", salesRate: "20%" },
      { name: "르꼬끄스포르티브", salesRate: "20%" },
      { name: "리복(3pcs 구매시)", salesRate: "20%" },
      { name: "먼싱웨어", salesRate: "20%" },
      { name: "반스(신발 2족 구매시)", salesRate: "20%" },
      { name: "스케쳐스(3PCS 구매시)", salesRate: "20%" },
      { name: "엄브로", salesRate: "20%" },
      { name: "제이린드버그", salesRate: "20%" },
      { name: "크록스 코리아(주중 15만원 이상 구매시)", salesRate: "20%" },
      { name: "프로스펙스", salesRate: "20%" },
      { name: "휠라(2PCS 이상 구매시)", salesRate: "20%" },
      { name: "BBC어스", salesRate: "20%" },

      { name: "노스페이스(10/30~11/1)", salesRate: "10%" },
      {
        name: "다이나핏(15/30만원 이상 구매시 추가 10/15% 할인)",
        salesRate: "10%",
      },
      { name: "리복(2pc 구매시)", salesRate: "10%" },
      { name: "만다리나덕", salesRate: "10%" },
      { name: "말본(11/6~8, 100만원 이상 구매시)", salesRate: "10%" },
      { name: "미즈노(10/30~11/1, 11/6~8)", salesRate: "10%" },
      { name: "밀레", salesRate: "10%" },
      { name: "볼디스트", salesRate: "10%" },
      { name: "볼빅", salesRate: "10%" },
      { name: "스케쳐스(2pcs 이상 구매시)", salesRate: "10%" },
      { name: "스파이더(20/40만원 이상 구매시 10/15% 할인)", salesRate: "10%" },
      { name: "시에라디자인", salesRate: "10%" },
      { name: "아페쎄골프(10/30~11/1)", salesRate: "10%" },
      { name: "어뉴(15%)", salesRate: "10%" },
      { name: "지포어(50만원 이상 구매시)", salesRate: "10%" },
      {
        name: "캘러웨이(멤버십 가입고객, 25FW상품 50만원 이상 구매시)",
        salesRate: "10%",
      },
      { name: "코오롱스포츠(신규 회원 가입 시)", salesRate: "10%" },
      { name: "크록스 코리아(주말 10만원 이상 구매시)", salesRate: "10%" },
      { name: "피엘라벤", salesRate: "10%" },
      { name: "ABC마트", salesRate: "10%" },
    ],
    ["나이키", "뉴발란스", "아디다스"],
  ),
  Acc: sortBrandsByName([
    { name: "고세(~50%)", salesRate: "30%" },
    { name: "바바라(~50%)", salesRate: "30%" },
    { name: "사만사타바사", salesRate: "30%" },
    { name: "스탠드오일", salesRate: "30%" },
    { name: "오브엠", salesRate: "30%" },
    { name: "와이컨셉", salesRate: "30%" },
    { name: "허시파피", salesRate: "30%" },

    { name: "락포트", salesRate: "20%" },
    { name: "루이까또즈", salesRate: "20%" },
    { name: "메트로시티", salesRate: "20%" },
    { name: "무크", salesRate: "20%" },
    { name: "소다", salesRate: "20%" },
    { name: "슈콤마보니", salesRate: "20%" },
    { name: "스케쳐스USA", salesRate: "20%" },
    { name: "에코(3pcs 구매시)", salesRate: "20%" },
    { name: "엘바테게브", salesRate: "20%" },
    { name: "와이컨셉", salesRate: "20%" },
    { name: "제이에스티나", salesRate: "20%" },
    { name: "캠퍼(3pcs 구매시)", salesRate: "20%" },
    { name: "쿠론", salesRate: "20%" },

    { name: "닥스", salesRate: "10%" },
    { name: "닥스ACC", salesRate: "10%" },
    { name: "라움에디션", salesRate: "10%" },
    { name: "락포트", salesRate: "10%" },
    { name: "룩옵티컬(수입렌즈 추가 15%할인)", salesRate: "10%" },
    { name: "모스바니", salesRate: "10%" },
    { name: "미니골드", salesRate: "10%" },
    { name: "미소페", salesRate: "10%" },
    { name: "베어파우", salesRate: "10%" },
    { name: "분크", salesRate: "10%" },
    { name: "스와로브스키(2pcs 구매시)", salesRate: "10%" },
    { name: "스톤헨지", salesRate: "10%" },
    { name: "스퍼", salesRate: "10%" },
    { name: "아메리칸투어리스터", salesRate: "10%" },
    { name: "아이에비뉴", salesRate: "10%" },
    { name: "아프리카", salesRate: "10%" },
    { name: "에스콰이아", salesRate: "10%" },
    { name: "에코(2pcs 구매시)", salesRate: "10%" },
    { name: "와이컨셉", salesRate: "10%" },
    { name: "제옥스/T.W.C", salesRate: "10%" },
    { name: "조이그라이슨", salesRate: "10%" },
    { name: "캠퍼(2pcs 구매시)", salesRate: "10%" },
    { name: "키플링", salesRate: "10%" },
    { name: "패션갤러리", salesRate: "10%" },
  ]),
  Kids: sortBrandsByName([
    { name: "네파키즈", salesRate: "20%" },
    { name: "뉴발란스키즈", salesRate: "20%" },
    { name: "스케쳐스키즈(3pcs 구매 시)", salesRate: "20%" },
    {
      name: "오가닉맘(출산제품 7만원 이상 구매 시 10/30~11/1)",
      salesRate: "20%",
    },
    { name: "지프키즈", salesRate: "20%" },
    { name: "휠라키즈(의류 포함 3개 이상 구매 시, 은평점)", salesRate: "20%" },

    { name: "내셔널지오그래픽키즈", salesRate: "10%" },
    { name: "스케쳐스키즈(2pcs 구매 시)", salesRate: "10%" },
    { name: "앙팡스", salesRate: "10%" },
    { name: "에스키즈", salesRate: "10%" },
    { name: "엠엘비키즈(20만원 이상 구매시)", salesRate: "10%" },
    { name: "오가닉맘(25-26 FW 제품 7만원이상 구매시)", salesRate: "10%" },
    { name: "지프키즈", salesRate: "10%" },
    { name: "토박스", salesRate: "10%" },
    { name: "프렌치캣", salesRate: "10%" },
    { name: "휠라키즈(의류 포함 2개 이상 구매 시, 은평점)", salesRate: "10%" },
  ]),
  "Living & Lifestyle": sortBrandsByName([
    { name: "덴비", salesRate: "30%" },
    { name: "본톤", salesRate: "30%" },
    { name: "시몬스", salesRate: "30%" },
    { name: "씰리", salesRate: "30%" },
    { name: "웨지우드", salesRate: "30%" },
    { name: "젠", salesRate: "30%" },
    { name: "템퍼", salesRate: "30%" },
    { name: "포트메리온", salesRate: "30%" },

    { name: "씰리", salesRate: "20%" },
    { name: "젠", salesRate: "20%" },
    { name: "코네소파", salesRate: "20%" },
    { name: "템퍼", salesRate: "20%" },

    { name: "까사부가티", salesRate: "10%" },
    { name: "누하스(3%)", salesRate: "10%" },
    { name: "다우닝(5%)", salesRate: "10%" },
    { name: "닥스침구", salesRate: "10%" },
    { name: "로라애슐리", salesRate: "10%" },
    { name: "메종플레장", salesRate: "10%" },
    { name: "봄소와(5%)", salesRate: "10%" },
    { name: "빌레로이앤보흐", salesRate: "10%" },
    { name: "운현궁", salesRate: "10%" },
    { name: "인아트(5%)", salesRate: "10%" },
    { name: "자코모", salesRate: "10%" },
    { name: "키친갤러리", salesRate: "10%" },
    { name: "키친갤러리(10만원 이상 구매시)", salesRate: "10%" },
    { name: "헹켈/즈윌링", salesRate: "10%" },
  ]),
};

function groupBrandsByCategory(brands) {
  const grouped = {
    "30%": [],
    "20%": [],
    "10%": [],
  };

  brands.forEach((brand) => {
    if (grouped[brand.salesRate]) {
      grouped[brand.salesRate].push(brand);
    }
  });

  return grouped;
}

// 전체 브랜드 데이터 (검색용)
const allBrands = [
  ...brandData["Luxury & Contemporary"],
  ...brandData["Fashion"],
  ...brandData["Acc"],
  ...brandData["Golf / Sports & Outdoor"],
  ...brandData["Kids"],
  ...brandData["Living & Lifestyle"],
];
