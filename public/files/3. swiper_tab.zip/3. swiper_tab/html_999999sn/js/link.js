const LinkSetting = (element, type, newWindow, link_val) => {
  const filter = "win16|win32|win64|mac|macintel";

  // * 링크 타입별 주소 [pc 웹, 모바일 웹, 앱]
  // * 함수 안에 두어 부모 페이지(모달 링크)에 전역 변수를 추가하지 않음
  const LINK_URLS = {
    coupon: [
      "https://www.lotteshopping.com/cpn/cpnDetail?cpnInfoNo=",
      "https://m.lotteshopping.com/cpn/cpnDetail?cpnInfoNo=",
      "lottecoupon://gate?page=a0026&cpnInfoNo=",
    ],
    shopping: [
      "https://www.lotteshopping.com/shpgnews/shpgnewsDetail?shpgNewsNo=",
      "https://m.lotteshopping.com/shpgnews/shpgnewsDetail?shpgNewsNo=",
      "lottecoupon://gate?page=a0083&shpgNewsNo=",
    ],
    saeun: [
      "https://www.lotteshopping.com/thku/thkuDetail?thkuNo=",
      "https://m.lotteshopping.com/thku/thkuDetail?thkuNo=",
      "lottecoupon://gate?page=a0065&thkuNo=",
    ],
    event: [
      "https://www.lotteshopping.com/cuterent/cuterentDetail?entNo=",
      "https://m.lotteshopping.com/cuterent/cuterentDetail?entNo=",
      "lottecoupon://gate?page=a0102&entNo=",
    ],
    magazine: [
      "https://www.lotteshopping.com/magazine/magazineDetail?mazinNo=",
      "https://m.lotteshopping.com/magazine/magazineDetail?mazinNo=",
      "lottecoupon://gate?page=a0086&mazinNo=",
    ],
    shopnow: [
      "https://www.lotteshopping.com/shopnow/cntsList?shpgHhlghNo=",
      "https://m.lotteshopping.com/shopnow/cntsList?shpgHhlghNo=",
      "lottecoupon://gate?page=a0137&url=https://m.lotteshopping.com/shopnow/cntsList?shpgHhlghNo=",
    ],
    mallApp: ["", "", "lottecoupon://gate?page=a0138&url="],
    xBrowser: ["", "", "lottecoupon://gate?page=a0240&url="],
    xBrowserOld: ["", "", "lottecoupon://gate?page=a0137&url="],
    browserOpen: ["", "", "lottecoupon://gate?page=a0168&url="],
    browserOpenSkip: ["", "", "lottecoupon://gate?page=a0258&url="],
    xBrowserLang: ["", "", "lottecouponglobal://gate?page=a0240&url="],
    browserOpenLang: ["", "", "lottecouponglobal://gate?page=a0168&url="],
    login: ["", "", ""],
    // * 이전 타입 (사용 안 함)
    // BrowserOpen: ["", "", "toapp:::AppViewMove:::BrowserOpen:::"],
    // sso: ["", "", "lottecoupon://gate?page=a0138&ssoYn=Y&url="],
  };

  // * 없는 타입이면 주소 앞부분 없이 link_val 그대로 사용 (기존 동작)
  const [pcweb_url, moweb_url, app_url] = Object.prototype.hasOwnProperty.call(
    LINK_URLS,
    type,
  )
    ? LINK_URLS[type]
    : ["", "", ""];

  // * yes / no 외의 값이면 yes
  if (newWindow !== "yes" && newWindow !== "no") {
    newWindow = "yes";
  }

  if (navigator.platform) {
    if (filter.indexOf(navigator.platform.toLowerCase()) >= 0) {
      // PCWEB 인 경우
      element.href = `${pcweb_url}${link_val}`;
      if (newWindow == "yes") {
        element.target = "_blank";
      }
    } else {
      const browserInfo = navigator.userAgent;

      if (
        browserInfo.indexOf("LD_Android") > -1 ||
        browserInfo.indexOf("LD_iOS") > -1
      ) {
        // 앱 링크
        // * mallApp은 url 전체를 인코딩 (공백은 +)
        if (type == "mallApp") {
          link_val = encodeURIComponent(link_val).replace(/%20/g, "+");
        }

        element.href = `${app_url}${link_val}`;
      } else {
        // 모바일 웹 링크
        element.href = `${moweb_url}${link_val}`;
        if (newWindow == "yes") {
          element.target = "_blank";
        }
      }
    }
  }
};
