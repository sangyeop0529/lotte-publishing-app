// *************************************************************************
// *************************************************************************
// * 2025.03.31 작업
// * 작업자 : 조윤상
// * version : v2.0 (2026.11.12 리팩토링 · 메시지 규격 v2)
// * outer.js와 자식 js는 반드시 같은 버전끼리 함께 배포
// *************************************************************************
// *************************************************************************

// TODO ********************************************************************
// ! 전역 변수
// TODO ********************************************************************

const tabArea = document.querySelectorAll(".tab-area");
const tabBtnArea = document.querySelector(".tab-btn-area");
const tabBtn = document.querySelectorAll(".tab-btn");
const tabBtnImage = tabBtn[0].querySelector("img");

// ! setupTabBtnArea - 탭 방식 설정 [S]
// * <div class="tab-btn-area" data-tab-type="basic | swiper">
// *   - basic  : 고정형 탭. 탭별 가로값은 css에서 조정 (균등 분할 아님)
// *   - swiper : 스와이프형 탭. .swiper > .swiper-wrapper 구조를 자동 생성
// * 이미 basic-tab / swiper-tab 클래스가 있는 예전 구조는 그대로 사용
const setupTabBtnArea = () => {
  if (
    tabBtnArea.classList.contains("basic-tab") ||
    tabBtnArea.classList.contains("swiper-tab")
  ) {
    return;
  }

  if (tabBtnArea.dataset.tabType === "swiper") {
    const swiperEl = document.createElement("div");
    const swiperWrapper = document.createElement("div");
    swiperEl.className = "swiper";
    swiperWrapper.className = "swiper-wrapper";

    tabBtn.forEach((element) => {
      element.classList.add("swiper-slide");
      swiperWrapper.appendChild(element);
    });

    swiperEl.appendChild(swiperWrapper);
    tabBtnArea.appendChild(swiperEl);
    tabBtnArea.classList.add("swiper-tab");
  } else {
    // * 탭 너비는 JS로 계산하지 않음 → css(tab-menu.css, outer.css)의 nth-child로 탭마다 지정
    tabBtnArea.classList.add("basic-tab");
  }
};
setupTabBtnArea();
// setupTabBtnArea - 탭 방식 설정 [E]

// TODO ********************************************************************
// ! postMessage 동작 - 보내기
// TODO ********************************************************************

// ! setTabDataInit setting - 데이터 초기화 메세지 보내기 [S]
// * force : true면 값이 같아도 전송 (부모 요청 시)
let lastTabValues = "";
const setTabDataInit = (force) => {
  // * 탭 상세,탭 버튼 영역 높이값 & 탭 상세,탭 버튼 영역 위치값 설정
  if (initCommonObj.isTabValues) {
    initCommonObj.tabAreaHeight = [];
    tabArea.forEach((element) => {
      initCommonObj.tabAreaHeight.push(element.getBoundingClientRect().height);
    });

    initCommonObj.tabAreaPosition = [];
    tabArea.forEach((element) => {
      initCommonObj.tabAreaPosition.push(
        element.getBoundingClientRect().top -
          tabBtnArea.getBoundingClientRect().height,
      );
    });

    initCommonObj.tabBtnAreaHeight = tabBtnArea.getBoundingClientRect().height;
    initCommonObj.tabBtnAreaPosition = tabBtnArea.getBoundingClientRect().top;

    const tabValues = {
      tabAreaHeight: initCommonObj.tabAreaHeight,
      tabAreaPosition: initCommonObj.tabAreaPosition,
      tabBtnAreaHeight: initCommonObj.tabBtnAreaHeight,
      tabBtnAreaPosition: initCommonObj.tabBtnAreaPosition,
    };

    // * 이전에 보낸 값과 같으면 전송하지 않음 (자동 감지로 자주 호출되므로)
    const tabValuesKey = JSON.stringify(tabValues);
    if (!force && tabValuesKey === lastTabValues) return;
    lastTabValues = tabValuesKey;

    sendToParent("tabValues", tabValues);
  }
};
setTabDataInit();
// setTabDataInit setting - 데이터 초기화 메세지 보내기 [E]

// ! tabClone - 탭 복사 설정 메세지 보내기 [S]
const tabClone = () => {
  let imgExtension;

  if (tabBtnArea.classList.contains("basic-tab")) {
    initCommonObj.isSwiper = false;
  } else if (tabBtnArea.classList.contains("swiper-tab")) {
    initCommonObj.isSwiper = true;
  }

  if (initCommonObj.isSwiper) {
    initCommonObj.swiperTab = new Swiper(".tab-btn-area.swiper-tab .swiper", {
      observer: true,
      observeParents: true,
      slidesPerView: "auto",
      freeMode: true,
      on: {
        setTranslate: function (swiper, translate) {
          slideTransform(translate);
        },
      },
    });
  }

  if (tabBtnImage.src.includes(".jpg")) {
    imgExtension = "jpg";
  } else if (tabBtnImage.src.includes(".png")) {
    imgExtension = "png";
  }

  sendToParent("tabClone", {
    count: tabBtn.length,
    imgExtension,
    isSwiper: initCommonObj.isSwiper,
  });
};
// tabClone - 탭 복사 설정 메세지 보내기 [E]

// ! tabClick 동작 메세지 보내기 [S]
const tabClickAction = (idx) => {
  if (initCommonObj.deviceState != "kiosk") {
    sendToParent("tabClickAction", {
      tabIdx: idx,
    });
  } else {
    tabBtn.forEach((element) => {
      element.classList.remove("on");
    });
    tabBtn[idx].classList.add("on");
    if (initCommonObj.isSwiper) {
      initCommonObj.swiperTab.slideTo(idx);
    }

    tabArea.forEach((element) => {
      element.style.display = "none";
    });
    tabArea[idx].style.display = "block";

    APP_EVENT(
      `[TAB]_${tabBtn[idx].dataset.tabName}`,
      `${contentName}_${contentCode}`,
      "TAB",
    );

    if (document.querySelector(".audio-range") != null) {
      audioStop(true);
    }
    setDataInit();
    setTabDataInit();
  }
};
// tabClick 동작 메세지 보내기 [E]

// ! slideTransform 동작 메세지 보내기 [S]
const slideTransform = (transform) => {
  sendToParent("tabSlideMove", {
    transform,
  });
};
// slideTransform 동작 메세지 보내기 [E]

// TODO ********************************************************************
// ! postMessage 동작 - 받기
// TODO ********************************************************************

// ! parent window message receive - parent window에서 메세지 받기 [S]
// * 탭 상세,탭 버튼 영역 높이값 & 탭 상세,탭 버튼 영역 위치값 설정
onParentMessage("requestTabValues", () => {
  initCommonObj.isTabValues = true;
  setTabDataInit(true);
});

// * 탭 복사
onParentMessage("requestTabClone", () => {
  tabClone();
});

// * 탭 연동 설정
onParentMessage("tabSlideMove", (param) => {
  if (!param || param.transform == undefined) return;

  const swiperWrapper = document.querySelector(
    ".tab-btn-area.swiper-tab .swiper-wrapper",
  );
  if (!swiperWrapper) return;

  swiperWrapper.style.transform = `translate3d(${param.transform}px, 0px, 0px)`;
});

// * 탭 태깅 설정
onParentMessage("setTabTagging", (param) => {
  if (!param || param.tabIdx === undefined) return;

  APP_EVENT(
    `[TAB]_${tabBtn[param.tabIdx].dataset.tabName}`,
    `${contentName}_${contentCode}`,
    "TAB",
  );
});
// parent window message receive - parent window에서 메세지 받기 [E]

// TODO ********************************************************************
// ! iframe 내부 동작
// TODO ********************************************************************

// ! kioskTabAreaInit - 키오스트 탭 초기화 [S]
const kioskTabAreaInit = () => {
  tabArea.forEach((element, idx) => {
    if (idx == 0) return;
    element.style.display = "none";
  });

  // setDataInit();
  // setTabDataInit();
};
// * 부모가 setDevice를 보낸 시점에 실행 (기존: 스크립트 실행 300ms 뒤 확인 → deviceState가 아직 없어 놓칠 수 있음)
// * common.js의 setDevice 처리가 먼저 등록되어 있어 deviceState는 이미 설정된 상태
onParentMessage("setDevice", (param) => {
  if (param && param.deviceState == "kiosk") {
    kioskTabAreaInit();
  }
});
// kioskTabAreaInit - 키오스트 탭 초기화 [E]

// ! tabClickFn - 탭 클릭 함수 [S]
const tabClickFn = () => {
  tabBtn.forEach((element, idx) => {
    element.addEventListener("click", () => tabClickAction(idx));
  });
};
tabClickFn();
// tabClickFn - 탭 클릭 함수 [E]
